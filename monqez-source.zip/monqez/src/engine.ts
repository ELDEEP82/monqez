/**
 * Monqez risk engine (prototype)
 * Risk Profile = f(Crop, Active_Substance, Δt (Harvest − Spray), PHI, EU_MRL, EU status, lab residue)
 * Batch P(rejection) = 1 − Π (1 − p_i)   (independent-violation assumption)
 */
import { Mrl, Substance, Trade, TRADE, mrlBySub, parseEuDate, subById, tradeById } from "./data";

export type Ref = { kind: "trade"; id: string } | { kind: "sub"; id: number } | null;

export type SprayRow = { uid: string; ref: Ref; date: string; rate: string; phi: number | "" };
export type OtherCategory = "postharvest_fungicide" | "insecticide" | "growth_regulator" | "storage" | "wax" | "other";
export type OtherTiming = "before_sampling" | "after_sampling" | "storage" | "mixture";
export type OtherRow = { uid: string; ref: Ref; category: OtherCategory; timing: OtherTiming; mixedWith: string; note: string };
export type LabRow = { uid: string; sid: number | null; value: string; nd: boolean };

export type Batch = {
  id: string;
  createdAt: string;
  exporter: string;
  batchCode: string;
  crop: "oranges";
  variety: string;
  destination: string;
  harvestDate: string;
  shipDate: string;
  tons: string;
  packhouse: string;
  sprays: SprayRow[];
  others: OtherRow[];
  labs: LabRow[];
  labName: string;
  sampleDate: string;
};

export type RegClass =
  | "approved" // approved in EU, numeric MRL on oranges
  | "lowMrl" // approved, numeric MRL but ≤ 0.05 mg/kg
  | "importTolerance" // not approved in EU, numeric MRL above LOQ (import tolerance / transitional)
  | "banned" // not approved + MRL at LOQ (*)
  | "noUseOnCrop" // approved in EU but MRL at LOQ for oranges
  | "annexIV" // approved, no orange MRL entry: likely exempt (Annex IV) – verify
  | "default" // not approved, no orange MRL entry → default 0.01 mg/kg (Art. 18(1)(b))
  | "unknown";

export type Level = "green" | "yellow" | "red";
export type Bi = { en: string; ar: string };

export type Item = {
  key: string;
  source: "spray" | "other" | "lab";
  rowUid: string;
  productEn: string;
  productAr: string;
  trade?: Trade;
  sub: Substance | null;
  subName: string;
  mrl: Mrl | null;
  mrlEff: number;
  regClass: RegClass;
  dt: number | null;
  phi: number | null;
  p: number;
  level: Level;
  reasons: Bi[];
  lab?: { value: number | null; nd: boolean; ratio: number | null };
  alternatives: Trade[];
  bannedSince: string | null;
  expirySoon: string | null;
};

export type Result = {
  items: Item[];
  pReject: number;
  pClear: number;
  level: Level;
  counts: Record<Level, number>;
  batchNotes: Bi[];
  warnings: Bi[];
};

const DAY = 86400000;
const days = (a: string, b: string) => Math.round((new Date(a).getTime() - new Date(b).getTime()) / DAY);
const fmt = (n: number) => (n >= 1 ? n.toFixed(2).replace(/\.00$/, "") : n.toPrecision(2));

export function classify(sub: Substance | null): { regClass: RegClass; mrl: Mrl | null; mrlEff: number } {
  if (!sub) return { regClass: "unknown", mrl: null, mrlEff: 0.01 };
  const mrl = mrlBySub.get(sub.id) ?? null;
  const approved = sub.status === "Approved";
  if (mrl) {
    if (mrl.mrl == null) return { regClass: approved ? "noUseOnCrop" : "default", mrl, mrlEff: 0.01 };
    if (mrl.loq) return { regClass: approved ? "noUseOnCrop" : "banned", mrl, mrlEff: mrl.mrl };
    if (!approved) return { regClass: "importTolerance", mrl, mrlEff: mrl.mrl };
    return { regClass: mrl.mrl <= 0.05 ? "lowMrl" : "approved", mrl, mrlEff: mrl.mrl };
  }
  return { regClass: approved ? "annexIV" : "default", mrl: null, mrlEff: 0.01 };
}

export const REG_LABEL: Record<RegClass, Bi> = {
  approved: { en: "EU-approved · MRL set", ar: "معتمد أوروبيًا · له حد أقصى" },
  lowMrl: { en: "EU-approved · very low MRL", ar: "معتمد · حد أقصى منخفض جدًا" },
  importTolerance: { en: "Not approved · import tolerance", ar: "غير معتمد · مسموح بحد استيراد" },
  banned: { en: "Banned in EU · zero tolerance (LOQ)", ar: "محظور أوروبيًا · صفر تسامح" },
  noUseOnCrop: { en: "No MRL for oranges (LOQ only)", ar: "لا يوجد حد للبرتقال (حد الكشف فقط)" },
  annexIV: { en: "Likely MRL-exempt (Annex IV)", ar: "غالبًا معفى من الحد (ملحق IV)" },
  default: { en: "Not approved · default 0.01 mg/kg", ar: "غير معتمد · الحد الافتراضي 0.01" },
  unknown: { en: "Unknown substance", ar: "مادة غير معروفة" },
};

const isZeroTol = (c: RegClass) => c === "banned" || c === "default" || c === "noUseOnCrop" || c === "unknown";

function levelOf(p: number, c: RegClass): Level {
  if (isZeroTol(c)) return "red";
  if (p >= 0.5) return "red";
  if (p >= 0.15) return "yellow";
  return "green";
}

function typeGroup(t: string) {
  if (t === "acaricide" || t === "insecticide" || t === "oil") return "pest";
  return t;
}

export function alternativesFor(item: { trade?: Trade; sub: Substance | null }): Trade[] {
  let group: string | null = item.trade ? typeGroup(item.trade.type) : null;
  if (!group && item.sub?.functions) {
    const f = item.sub.functions;
    group = /FU/.test(f) ? "fungicide" : /PG/.test(f) ? "growth regulator" : /HB/.test(f) ? "herbicide" : /IN|AC/.test(f) ? "pest" : null;
  }
  if (!group) return [];
  return TRADE.filter((t) => typeGroup(t.type) === group && t.id !== item.trade?.id)
    .filter((t) =>
      t.ai.every((a) => {
        const s = a.sid != null ? subById.get(a.sid) ?? null : null;
        const c = classify(s).regClass;
        return c === "approved" || c === "annexIV";
      })
    )
    .sort((a, b) => a.phi - b.phi)
    .slice(0, 3);
}

function resolveRef(ref: Ref): { trade?: Trade; subs: Substance[]; en: string; ar: string } | null {
  if (!ref) return null;
  if (ref.kind === "trade") {
    const t = tradeById.get(ref.id);
    if (!t) return null;
    const subs = t.ai.map((a) => (a.sid != null ? subById.get(a.sid) : undefined)).filter(Boolean) as Substance[];
    return { trade: t, subs, en: `${t.en} ${t.form !== "—" ? t.form : ""}`.trim(), ar: `${t.ar} ${t.form !== "—" ? `\u2066${t.form}\u2069` : ""}`.trim() };
  }
  const s = subById.get(ref.id);
  if (!s) return null;
  return { subs: [s], en: s.name, ar: s.name };
}

function bannedSince(sub: Substance | null): string | null {
  if (!sub || sub.status === "Approved") return null;
  return sub.expiry ?? null;
}

function expirySoon(sub: Substance | null, ref: string): string | null {
  if (!sub || sub.status !== "Approved" || !sub.expiry) return null;
  const d = parseEuDate(sub.expiry);
  if (!d) return null;
  const base = ref ? new Date(ref) : new Date();
  const diff = (d.getTime() - base.getTime()) / DAY;
  return diff < 365 ? sub.expiry : null;
}

function labPart(sub: Substance | null, labs: LabRow[], mrlEff: number) {
  if (!sub) return undefined;
  const row = labs.find((l) => l.sid === sub.id);
  if (!row) return undefined;
  const v = row.nd ? 0 : parseFloat(row.value);
  if (!row.nd && !isFinite(v)) return undefined;
  return { value: row.nd ? null : v, nd: row.nd, ratio: row.nd ? 0 : v / mrlEff };
}

function pFromLab(ratio: number): number {
  if (ratio > 2) return 0.98;
  if (ratio > 1) return 0.9;
  if (ratio > 0.7) return 0.35;
  if (ratio > 0.3) return 0.1;
  if (ratio > 0) return 0.03;
  return 0.01;
}

export function evaluate(b: Batch): Result {
  const items: Item[] = [];
  const warnings: Bi[] = [];
  const covered = new Set<number>();

  if (!b.harvestDate) warnings.push({ en: "Harvest date is missing — PHI checks use today's date.", ar: "تاريخ الحصاد غير محدد — تم استخدام تاريخ اليوم لحساب فترة الأمان." });
  if (b.harvestDate && b.shipDate && days(b.shipDate, b.harvestDate) < 0)
    warnings.push({ en: "Shipping date is before harvest date.", ar: "تاريخ الشحن قبل تاريخ الحصاد." });
  const harvest = b.harvestDate || new Date().toISOString().slice(0, 10);

  const push = (src: Item["source"], rowUid: string, info: ReturnType<typeof resolveRef>, sub: Substance, ctx: { dt: number | null; phi: number | null; timing?: OtherTiming; category?: OtherCategory; mixedWith?: string }) => {
    const { regClass, mrl, mrlEff } = classify(sub);
    const reasons: Bi[] = [];
    let p = 0.05;
    const lab = labPart(sub, b.labs, mrlEff);
    covered.add(sub.id);
    const postHarvest = src === "other" && (ctx.timing === "storage" || ctx.timing === "after_sampling" || ctx.category === "postharvest_fungicide" || ctx.category === "wax" || ctx.category === "storage");

    // ---- regulatory statement
    const mrlTxt = mrl?.raw ?? "0.01 (default)";
    if (regClass === "banned")
      reasons.push({ en: `Not approved under Reg. (EC) 1107/2009; EU MRL on oranges is set at the analytical limit (${mrlTxt} mg/kg) — any detectable residue is a violation.`, ar: `غير معتمد وفق اللائحة 1107/2009؛ الحد الأقصى على البرتقال عند حد الكشف المعملي (${mrlTxt} مجم/كجم) — أي متبقي يُكتشف يعتبر مخالفة.` });
    else if (regClass === "default")
      reasons.push({ en: "Not approved in the EU and no orange-specific MRL is listed → the default limit of 0.01 mg/kg applies (Art. 18(1)(b), Reg. 396/2005).", ar: "غير معتمد في الاتحاد الأوروبي ولا يوجد حد خاص بالبرتقال ← يُطبق الحد الافتراضي 0.01 مجم/كجم (المادة 18(1)(ب) من اللائحة 396/2005)." });
    else if (regClass === "noUseOnCrop")
      reasons.push({ en: `Approved in the EU but not for oranges: MRL is at the detection limit (${mrlTxt} mg/kg).`, ar: `معتمد أوروبيًا لكن غير مصرح على البرتقال: الحد عند حد الكشف (${mrlTxt} مجم/كجم).` });
    else if (regClass === "importTolerance")
      reasons.push({ en: `Not approved for use in the EU, but an MRL of ${mrlTxt} mg/kg exists for oranges (import tolerance). Legal up to this limit — but such MRLs are often lowered at review.`, ar: `غير معتمد للاستخدام داخل الاتحاد الأوروبي، لكن يوجد حد ${mrlTxt} مجم/كجم للبرتقال (حد استيراد). قانوني حتى هذا الحد — لكن هذه الحدود كثيرًا ما تُخفض عند المراجعة.` });
    else if (regClass === "approved" || regClass === "lowMrl")
      reasons.push({ en: `EU-approved; MRL on oranges ${mrlTxt} mg/kg.${regClass === "lowMrl" ? " Very low limit — small overdoses can exceed it." : ""}`, ar: `معتمد أوروبيًا؛ الحد الأقصى على البرتقال ${mrlTxt} مجم/كجم.${regClass === "lowMrl" ? " الحد منخفض جدًا — أي زيادة بسيطة في الجرعة قد تتخطاه." : ""}` });
    else if (regClass === "annexIV")
      reasons.push({ en: "EU-approved and absent from the orange MRL list — typically an Annex IV substance (no MRL required). Verify the exact compound/CAS.", ar: "معتمد أوروبيًا وغير موجود في قائمة حدود البرتقال — غالبًا من مواد الملحق IV (لا يتطلب حدًا). تحقق من المركب/رقم CAS بالضبط." });

    // ---- probability
    const phi = ctx.phi;
    const dt = ctx.dt;
    if (postHarvest) {
      if (isZeroTol(regClass)) p = 0.95;
      else if (regClass === "importTolerance") p = 0.35;
      else if (regClass === "annexIV") p = 0.02;
      else p = regClass === "lowMrl" ? 0.35 : 0.15;
      reasons.push({ en: "Applied after harvest / in storage: residues stay on the fruit surface with almost no decline before arrival.", ar: "تم استخدامه بعد الحصاد / في التخزين: المتبقيات تبقى على سطح الثمرة تقريبًا بدون تكسير حتى الوصول." });
      if (ctx.timing === "after_sampling")
        reasons.push({ en: "Used AFTER the lab sample was taken — your lab report does not reflect this substance.", ar: "تم استخدامه بعد أخذ عينة المعمل — تقرير المعمل لا يعكس هذه المادة." });
    } else if (dt != null && phi != null) {
      const margin = Math.max(phi * (regClass === "lowMrl" || regClass === "importTolerance" ? 1.5 : 1.3), phi + 7);
      if (isZeroTol(regClass)) {
        p = dt < phi ? 0.95 : dt < 2 * phi ? 0.75 : dt < 4 * phi ? 0.5 : 0.3;
        reasons.push({ en: `Δt = ${dt} days (PHI ${phi}). For a zero-tolerance substance, no interval guarantees compliance — a residue lab test is mandatory.`, ar: `الفترة = ${dt} يوم (فترة الأمان ${phi}). لمادة صفر تسامح لا توجد فترة تضمن المطابقة — تحليل متبقيات إلزامي.` });
      } else if (regClass === "annexIV") {
        p = 0.01;
      } else if (dt < 0) {
        p = 0.6;
        reasons.push({ en: "Application date is after harvest date — check the record.", ar: "تاريخ الرش بعد تاريخ الحصاد — راجع السجل." });
      } else if (dt < phi) {
        p = regClass === "importTolerance" ? 0.75 : 0.65;
        reasons.push({ en: `Harvested ${dt} days after spraying — before the PHI of ${phi} days expired (${phi - dt} days short).`, ar: `تم الحصاد بعد ${dt} يوم من الرش — قبل انتهاء فترة الأمان ${phi} يوم (ناقص ${phi - dt} يوم).` });
      } else if (dt < margin) {
        p = regClass === "importTolerance" ? 0.28 : regClass === "lowMrl" ? 0.25 : 0.18;
        reasons.push({ en: `Δt = ${dt} days: past the PHI (${phi}) but inside the safety margin (${Math.round(margin)} days). Pre-export lab test recommended.`, ar: `الفترة = ${dt} يوم: بعد فترة الأمان (${phi}) لكن داخل هامش الأمان (${Math.round(margin)} يوم). يُنصح بتحليل قبل التصدير.` });
      } else {
        p = regClass === "importTolerance" ? 0.08 : regClass === "lowMrl" ? 0.05 : 0.03;
        reasons.push({ en: `Δt = ${dt} days — comfortably beyond the PHI of ${phi} days.`, ar: `الفترة = ${dt} يوم — أكبر بوضوح من فترة الأمان ${phi} يوم.` });
      }
    } else {
      p = isZeroTol(regClass) ? 0.85 : regClass === "annexIV" ? 0.02 : 0.2;
      reasons.push({ en: "No application date / PHI provided — timing could not be assessed.", ar: "لم يتم إدخال تاريخ الرش / فترة الأمان — لم يتم تقييم التوقيت." });
    }

    if (src === "other" && ctx.timing === "mixture")
      reasons.push({ en: `Tank-mixed${ctx.mixedWith ? ` with “${ctx.mixedWith}”` : ""}: even a small share of a non-permitted product produces a violation.`, ar: `تم خلطه${ctx.mixedWith ? ` مع «${ctx.mixedWith}»` : ""}: حتى نسبة ضئيلة من مادة غير مسموحة تسبب مخالفة.` });

    // ---- lab override
    if (lab) {
      const lp = pFromLab(lab.ratio ?? 0);
      if (!(src === "other" && ctx.timing === "after_sampling")) p = lp;
      if (lab.nd) reasons.push({ en: "Lab: not detected (< LOQ).", ar: "المعمل: لم يتم الكشف (أقل من حد الكشف)." });
      else if (lab.ratio != null) {
        const pct = Math.round(lab.ratio * 100);
        if (lab.ratio > 1)
          reasons.push({ en: `Lab: ${fmt(lab.value!)} mg/kg = ${pct}% of the MRL — exceeds the limit by ${fmt(lab.value! - mrlEff)} mg/kg${lab.ratio > 2 ? " (non-compliant even after the 50% EU measurement-uncertainty allowance)" : ""}.`, ar: `المعمل: ${fmt(lab.value!)} مجم/كجم = ${pct}% من الحد — يتخطى الحد بمقدار ${fmt(lab.value! - mrlEff)} مجم/كجم${lab.ratio > 2 ? " (مخالف حتى بعد احتساب هامش عدم اليقين الأوروبي 50%)" : ""}.` });
        else reasons.push({ en: `Lab: ${fmt(lab.value!)} mg/kg = ${pct}% of the MRL.`, ar: `المعمل: ${fmt(lab.value!)} مجم/كجم = ${pct}% من الحد.` });
      }
    }

    const level = levelOf(p, regClass);
    const exp = expirySoon(sub, b.shipDate || harvest);
    if (exp) reasons.push({ en: `EU approval expires ${exp} — MRL may be reviewed and lowered.`, ar: `الاعتماد الأوروبي ينتهي ${exp} — قد تتم مراجعة الحد وتخفيضه.` });
    if (sub.cfs) reasons.push({ en: `Candidate for substitution (${sub.cfs}).`, ar: `مرشح للاستبدال (${sub.cfs}).` });

    const it: Item = {
      key: `${rowUid}-${sub.id}`,
      source: src,
      rowUid,
      productEn: info?.en ?? sub.name,
      productAr: info?.ar ?? sub.name,
      trade: info?.trade,
      sub,
      subName: sub.name,
      mrl,
      mrlEff,
      regClass,
      dt,
      phi,
      p,
      level,
      reasons,
      lab,
      alternatives: [],
      bannedSince: bannedSince(sub),
      expirySoon: exp,
    };
    if (level !== "green") it.alternatives = alternativesFor({ trade: info?.trade, sub });
    items.push(it);
  };

  for (const r of b.sprays) {
    const info = resolveRef(r.ref);
    if (!info) continue;
    const phi = r.phi === "" ? info.trade?.phi ?? null : Number(r.phi);
    const dt = r.date ? days(harvest, r.date) : null;
    for (const s of info.subs) push("spray", r.uid, info, s, { dt, phi });
  }
  for (const r of b.others) {
    const info = resolveRef(r.ref);
    if (!info) continue;
    for (const s of info.subs) push("other", r.uid, info, s, { dt: null, phi: info.trade?.phi ?? null, timing: r.timing, category: r.category, mixedWith: r.mixedWith });
  }
  // lab-only detections (substance found by the lab but not declared)
  for (const l of b.labs) {
    if (l.sid == null || covered.has(l.sid)) continue;
    const sub = subById.get(l.sid);
    if (!sub) continue;
    const { regClass, mrl, mrlEff } = classify(sub);
    const lab = labPart(sub, b.labs, mrlEff);
    if (!lab) continue;
    const p = pFromLab(lab.ratio ?? 0);
    const reasons: Bi[] = [
      { en: "Detected by the lab but NOT declared in the spray record — possible cross-contamination, drift or undeclared mixture.", ar: "اكتشفه المعمل لكنه غير مسجل في برنامج الرش — احتمال تلوث عرضي أو انجراف رذاذ أو خلط غير مسجل." },
    ];
    if (lab.nd) reasons.push({ en: "Lab: not detected (< LOQ).", ar: "المعمل: لم يتم الكشف." });
    else reasons.push({ en: `Lab: ${fmt(lab.value!)} mg/kg vs MRL ${mrl?.raw ?? "0.01"} mg/kg (${Math.round((lab.ratio ?? 0) * 100)}%).`, ar: `المعمل: ${fmt(lab.value!)} مجم/كجم مقابل حد ${mrl?.raw ?? "0.01"} مجم/كجم (${Math.round((lab.ratio ?? 0) * 100)}%).` });
    const level = lab.nd ? "green" : levelOf(p, regClass);
    items.push({
      key: `lab-${l.uid}`,
      source: "lab",
      rowUid: l.uid,
      productEn: sub.name,
      productAr: sub.name,
      sub,
      subName: sub.name,
      mrl,
      mrlEff,
      regClass,
      dt: null,
      phi: null,
      p: lab.nd ? 0.01 : p,
      level,
      reasons,
      lab,
      alternatives: level !== "green" ? alternativesFor({ sub }) : [],
      bannedSince: bannedSince(sub),
      expirySoon: null,
    });
  }

  const pClear = items.reduce((acc, i) => acc * (1 - i.p), 1);
  const pReject = 1 - pClear;
  const counts = { green: 0, yellow: 0, red: 0 } as Record<Level, number>;
  items.forEach((i) => counts[i.level]++);
  const level: Level = counts.red ? "red" : counts.yellow || pReject >= 0.15 ? "yellow" : "green";

  const batchNotes: Bi[] = [];
  if (b.others.length === 0)
    batchNotes.push({ en: "No post-harvest / storage substances were declared. Many rejections come from treatments applied in the packhouse or store — declare them for a complete check.", ar: "لم يتم إدخال مواد ما بعد الحصاد / التخزين. كثير من حالات الرفض تأتي من معاملات في محطة التعبئة أو المخزن — أدخلها لفحص كامل." });
  if (b.labs.length === 0 && level !== "green")
    batchNotes.push({ en: "Add a residue lab report to replace estimates with measured values.", ar: "أضف تقرير معمل المتبقيات لاستبدال التقديرات بقيم مقاسة." });

  return { items: items.sort((a, z) => z.p - a.p), pReject, pClear, level, counts, batchNotes, warnings };
}

export function uid() {
  return Math.random().toString(36).slice(2, 10);
}

export function emptyBatch(): Batch {
  return {
    id: uid(),
    createdAt: new Date().toISOString(),
    exporter: "",
    batchCode: `MQZ-${new Date().toISOString().slice(2, 10).replace(/-/g, "")}-${Math.floor(Math.random() * 900 + 100)}`,
    crop: "oranges",
    variety: "Valencia",
    destination: "NL",
    harvestDate: new Date().toISOString().slice(0, 10),
    shipDate: new Date(Date.now() + 3 * DAY).toISOString().slice(0, 10),
    tons: "24",
    packhouse: "",
    sprays: [{ uid: uid(), ref: null, date: "", rate: "", phi: "" }],
    others: [],
    labs: [],
    labName: "",
    sampleDate: "",
  };
}

const iso = (offset: number, base?: string) => new Date((base ? new Date(base).getTime() : Date.now()) + offset * DAY).toISOString().slice(0, 10);

export function demoBatch(kind: "risky" | "clean"): Batch {
  const harvest = iso(0);
  const t = (en: string) => TRADE.find((x) => x.en === en)!.id;
  const sid = (name: string) => [...subById.values()].find((s) => s.name === name)!.id;
  if (kind === "clean")
    return {
      ...emptyBatch(),
      exporter: "Delta Citrus Co. (demo)",
      variety: "Navel",
      destination: "DE",
      harvestDate: harvest,
      shipDate: iso(4),
      packhouse: "Sadat City packhouse (demo)",
      sprays: [
        { uid: uid(), ref: { kind: "trade", id: t("Vertimec") }, date: iso(-40), rate: "40 ml/100 L", phi: 7 },
        { uid: uid(), ref: { kind: "trade", id: t("Admiral") }, date: iso(-55), rate: "50 ml/100 L", phi: 14 },
        { uid: uid(), ref: { kind: "trade", id: t("Score") }, date: iso(-30), rate: "50 ml/100 L", phi: 14 },
      ],
      others: [{ uid: uid(), ref: { kind: "trade", id: t("Fungaflor") }, category: "postharvest_fungicide", timing: "before_sampling", mixedWith: "", note: "" }],
      labs: [
        { uid: uid(), sid: sid("Imazalil (aka enilconazole)"), value: "1.2", nd: false },
        { uid: uid(), sid: sid("Abamectin (aka avermectin)"), value: "", nd: true },
      ],
      labName: "QCAP lab (demo)",
      sampleDate: iso(1),
    };
  return {
    ...emptyBatch(),
    exporter: "Nile Valley Exports (demo)",
    variety: "Valencia",
    destination: "NL",
    harvestDate: harvest,
    shipDate: iso(3),
    packhouse: "Nubaria packhouse (demo)",
    sprays: [
      { uid: uid(), ref: { kind: "trade", id: t("Dursban") }, date: iso(-35), rate: "150 ml/100 L", phi: 21 },
      { uid: uid(), ref: { kind: "trade", id: t("Mospilan") }, date: iso(-16), rate: "25 g/100 L", phi: 14 },
      { uid: uid(), ref: { kind: "trade", id: t("Proclaim") }, date: iso(-5), rate: "30 g/100 L", phi: 7 },
      { uid: uid(), ref: { kind: "trade", id: t("Vertimec") }, date: iso(-45), rate: "40 ml/100 L", phi: 7 },
    ],
    others: [
      { uid: uid(), ref: { kind: "trade", id: t("Sportak") }, category: "postharvest_fungicide", timing: "after_sampling", mixedWith: "", note: "" },
      { uid: uid(), ref: { kind: "trade", id: t("Tecto") }, category: "postharvest_fungicide", timing: "mixture", mixedWith: "Sportak", note: "" },
    ],
    labs: [
      { uid: uid(), sid: sid("Chlorpyrifos"), value: "0.03", nd: false },
      { uid: uid(), sid: sid("Thiabendazole"), value: "4.1", nd: false },
    ],
    labName: "Residue lab (demo)",
    sampleDate: iso(1),
  };
}
