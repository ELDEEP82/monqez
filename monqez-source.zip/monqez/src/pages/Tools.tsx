import { useEffect, useMemo, useRef, useState } from "react";
import { ScanLine, Package, Leaf, Upload, Loader2, ThermometerSnowflake, Droplets, Wind, Box, AlertTriangle, CheckCircle2 } from "lucide-react";
import { useLang } from "../lang";
import { Btn, Card, Field, LevelChip, SectionTitle, inputCls } from "../ui";
import { SUBSTANCES, TRADE, subById, Trade } from "../data";
import { classify, Level, REG_LABEL } from "../engine";
import { go } from "../App";

type Tab = "scan" | "pack" | "carbon";
function tabFromHash(): Tab {
  const m = location.hash.match(/tab=(scan|pack|carbon)/);
  return (m?.[1] as Tab) ?? "scan";
}

export default function Tools() {
  const { tr } = useLang();
  const [tab, setTab] = useState<Tab>(tabFromHash());
  useEffect(() => {
    const h = () => setTab(tabFromHash());
    window.addEventListener("hashchange", h);
    return () => window.removeEventListener("hashchange", h);
  }, []);
  const tabs: [Tab, string, typeof ScanLine][] = [
    ["scan", tr("Label scanner", "ماسح العبوة"), ScanLine],
    ["pack", tr("Packaging advisor", "مستشار التعبئة"), Package],
    ["carbon", tr("Carbon footprint", "البصمة الكربونية"), Leaf],
  ];
  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <SectionTitle kicker={tr("Beyond MRLs", "أبعد من الحدود القصوى")} title={tr("Export tools (beta)", "أدوات التصدير (تجريبي)")} sub={tr("Early versions of the platform modules in the Monqez roadmap.", "نسخ أولية من وحدات المنصة في خطة تطوير منقذ.")} />
      <div className="mb-6 flex flex-wrap gap-2">
        {tabs.map(([k, l, I]) => (
          <button key={k} onClick={() => { location.hash = `/tools?tab=${k}`; }} className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold ${tab === k ? "bg-ink-900 text-white dark:bg-leaf-600" : "bg-white ring-1 ring-sand-200 dark:bg-ink-900 dark:ring-ink-700"}`}>
            <I className="h-4 w-4" />{l}
          </button>
        ))}
      </div>
      {tab === "scan" && <Scanner />}
      {tab === "pack" && <Packaging />}
      {tab === "carbon" && <Carbon />}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Label scanner: OCR in the browser (tesseract.js) + fuzzy match      */
/* ------------------------------------------------------------------ */
const DEMO_TEXT = "CITRO-GUARD 48% EC\nActive ingredient:\nChlorpyrifos 480 g/L\nInsecticide - Emulsifiable concentrate\nPre-harvest interval: 21 days";

async function ocr(src: string, onProgress: (p: number) => void): Promise<string> {
  const T = await import("tesseract.js");
  const logger = (m: { status: string; progress: number }) => m.status === "recognizing text" && onProgress(m.progress);
  const base = new URL(".", location.href).href;
  let worker;
  try {
    const flat = import.meta.env.MODE === "single";
    worker = await T.createWorker("eng", 1, { workerPath: `${base}${flat ? "" : "ocr/"}worker.min.js`, corePath: flat ? base.replace(/\/$/, "") : `${base}ocr/core`, langPath: flat ? base.replace(/\/$/, "") : `${base}ocr/lang`, logger });
  } catch {
    worker = await T.createWorker("eng", 1, { logger });
  }
  try {
    const r = await worker.recognize(src);
    return r.data.text.trim();
  } finally {
    await worker.terminate();
  }
}

type Match = { trade?: Trade; subId?: number; score: number; label: string };
function matchText(text: string): Match[] {
  const t = text.toLowerCase().replace(/[^a-z0-9؀-ۿ%.\- ]+/g, " ");
  const out: Match[] = [];
  for (const tr of TRADE) {
    const names = [tr.en.toLowerCase(), tr.en.toLowerCase().split(" ")[0], tr.ar];
    let s = 0;
    if (names.some((n) => n.length >= 4 && t.includes(n))) s += 3;
    if (!s) continue;
    for (const a of tr.ai) if (t.includes(a.substance.toLowerCase().split(" (")[0].split("/")[0])) s += 2;
    out.push({ trade: tr, score: s, label: tr.en });
  }
  for (const sb of SUBSTANCES) {
    const n = sb.name.toLowerCase().split(" (")[0].split("/")[0];
    if (n.length >= 6 && t.includes(n) && !out.some((o) => o.trade?.ai.some((a) => a.sid === sb.id))) out.push({ subId: sb.id, score: 2, label: sb.name });
  }
  return out.sort((a, b) => b.score - a.score).slice(0, 4);
}

function sampleLabel(): string {
  const c = document.createElement("canvas");
  c.width = 900; c.height = 520;
  const g = c.getContext("2d")!;
  g.fillStyle = "#f4f1e8"; g.fillRect(0, 0, 900, 520);
  g.fillStyle = "#1b5437"; g.fillRect(0, 0, 900, 110);
  g.fillStyle = "#fff"; g.font = "bold 64px Arial"; g.fillText("CITRO-GUARD 48% EC", 40, 80);
  g.fillStyle = "#111"; g.font = "bold 40px Arial"; g.fillText("Active ingredient:", 40, 190);
  g.font = "40px Arial"; g.fillText("Chlorpyrifos 480 g/L", 40, 250);
  g.font = "30px Arial"; g.fillText("Insecticide - Emulsifiable concentrate", 40, 320);
  g.fillText("Pre-harvest interval: 21 days", 40, 370);
  g.fillText("Net content: 1 L", 40, 420);
  g.fillStyle = "#cc5a09"; g.font = "bold 26px Arial"; g.fillText("DEMO LABEL - FICTIONAL PRODUCT", 40, 490);
  return c.toDataURL("image/png");
}

function Scanner() {
  const { tr, bi, lang } = useLang();
  const [img, setImg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [text, setText] = useState("");
  const [err, setErr] = useState("");
  const [progress, setProgress] = useState(0);
  const file = useRef<HTMLInputElement>(null);
  const matches = useMemo(() => (text ? matchText(text) : []), [text]);

  const run = async (src: string, demo = false) => {
    setImg(src); setBusy(true); setErr(""); setText(""); setProgress(0);
    try {
      const out = await Promise.race([ocr(src, setProgress), new Promise<string>((_, rej) => setTimeout(() => rej(new Error("timeout")), 45000))]);
      setText(out);
    } catch {
      if (demo) setText(DEMO_TEXT);
      setErr(tr("The OCR engine could not load on this connection. Type the text printed on the label instead.", "محرك قراءة النص لم يتم تحميله على هذا الاتصال. اكتب النص المطبوع على العبوة بدلًا من ذلك."));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <Card className="p-5">
        <h3 className="font-display text-lg font-bold">{tr("Photograph a pesticide label", "صوّر عبوة المبيد")}</h3>
        <p className="mt-1 text-sm text-ink-700/70 dark:text-sand-200/60">{tr("Text is read in your browser (no upload), then matched to trade names and EU active substances.", "النص بيتقري داخل المتصفح (بدون رفع)، وبعدين بيتطابق مع الأسماء التجارية والمواد الفعالة الأوروبية.")}</p>
        <input ref={file} type="file" accept="image/*" capture="environment" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) { const r = new FileReader(); r.onload = () => run(r.result as string); r.readAsDataURL(f); } }} />
        <div className="mt-4 flex flex-wrap gap-2">
          <Btn onClick={() => file.current?.click()}><Upload className="h-4 w-4" />{tr("Upload / take photo", "ارفع / صوّر")}</Btn>
          <Btn variant="soft" onClick={() => run(sampleLabel(), true)}>{tr("Try a demo label", "جرّب عبوة توضيحية")}</Btn>
        </div>
        {img && <img src={img} alt="" className="mt-4 max-h-64 w-full rounded-xl object-contain ring-1 ring-sand-200 dark:ring-ink-700" />}
        {busy && <div className="mt-3 flex items-center gap-2 text-sm"><Loader2 className="h-4 w-4 animate-spin" />{tr("Reading label…", "جاري قراءة العبوة…")} {Math.round(progress * 100)}%</div>}
        {err && <div className="mt-3 rounded-lg bg-amber-50 p-3 text-sm text-amber-900 dark:bg-amber-950/40 dark:text-amber-200">{err}</div>}
        <Field label={tr("Recognised text (editable)", "النص المقروء (قابل للتعديل)")}>
          <textarea value={text} onChange={(e) => setText(e.target.value)} rows={5} dir="ltr" className={`${inputCls} mt-3 font-mono text-xs`} placeholder="e.g. Vertimec 1.8% EC — Abamectin" />
        </Field>
      </Card>
      <Card className="p-5">
        <h3 className="font-display text-lg font-bold">{tr("Identification", "التعرّف")}</h3>
        {!text && <p className="mt-6 text-center text-sm text-ink-700/60 dark:text-sand-200/50">{tr("Results appear here.", "النتائج هتظهر هنا.")}</p>}
        {text && matches.length === 0 && <p className="mt-6 text-sm text-ink-700/70">{tr("No known product or active substance found in the text.", "لم يتم العثور على منتج أو مادة فعالة معروفة في النص.")}</p>}
        <div className="mt-4 space-y-3">
          {matches.map((m, i) => {
            const subs = m.trade ? m.trade.ai.map((a) => (a.sid != null ? subById.get(a.sid)! : null)).filter(Boolean) : [subById.get(m.subId!)!];
            return (
              <div key={i} className="rounded-xl border border-sand-200 p-4 dark:border-ink-700">
                <div className="font-display font-bold">{m.trade ? (lang === "ar" ? m.trade.ar : m.trade.en) : <span dir="ltr">{m.label}</span>}</div>
                {m.trade && <div className="text-xs text-ink-700/70 dark:text-sand-200/60">{m.trade.type} · PHI {m.trade.phi} · {m.trade.rate}</div>}
                {!m.trade && <div className="text-xs text-ink-700/70 dark:text-sand-200/60">{tr("Active substance identified on the label", "مادة فعالة تم التعرف عليها من العبوة")}{(() => { const ts = TRADE.filter((x) => x.ai.some((a) => a.sid === m.subId)); return ts.length ? ` · ${tr("also sold as", "تُباع أيضًا باسم")}: ${ts.map((x) => (lang === "ar" ? x.ar : x.en)).join("، ")}` : ""; })()}</div>}
                {subs.map((s) => {
                  const c = classify(s!);
                  const lv: Level = ["banned", "default", "noUseOnCrop", "unknown"].includes(c.regClass) ? "red" : c.regClass === "importTolerance" || c.regClass === "lowMrl" ? "yellow" : "green";
                  return (
                    <div key={s!.id} className="mt-2 flex flex-wrap items-center justify-between gap-2 rounded-lg bg-sand-100 p-2.5 text-sm dark:bg-ink-800">
                      <span dir="ltr">{s!.name}</span>
                      <span className="flex items-center gap-2 text-xs">{bi(REG_LABEL[c.regClass])} <LevelChip level={lv} /></span>
                    </div>
                  );
                })}
              </div>
            );
          })}
        </div>
        {matches.length > 0 && <Btn variant="dark" className="mt-4" onClick={() => go("check")}>{tr("Use in a batch check", "استخدمه في فحص شحنة")}</Btn>}
        <p className="mt-6 text-[11px] text-ink-700/60 dark:text-sand-200/50">{tr("Prototype: English-text OCR. Production version: image-recognition model trained on Egyptian product packaging + Arabic OCR.", "نموذج أولي: قراءة نص إنجليزي. النسخة النهائية: نموذج تعرّف على الصور مدرب على عبوات السوق المصري + قراءة النص العربي.")}</p>
      </Card>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Packaging advisor (oranges)                                         */
/* ------------------------------------------------------------------ */
function Packaging() {
  const { tr } = useLang();
  const [transit, setTransit] = useState(12);
  const [variety, setVariety] = useState("Valencia");
  const [mixed, setMixed] = useState(false);
  const [degreened, setDegreened] = useState(false);
  const [wood, setWood] = useState(true);
  const temp = variety === "Navel" ? "4–6 °C" : variety === "Blood" ? "6–8 °C" : "3–6 °C";
  const tips: { ok: boolean; en: string; ar: string }[] = [
    { ok: true, en: `40' high-cube reefer, set point ${temp}; pre-cool fruit to pulp temperature before stuffing — reefers maintain, they don't pull down heat.`, ar: `حاوية مبردة 40 قدم HC، درجة الضبط ${temp}؛ برّد الثمار مسبقًا لدرجة حرارة اللب قبل التحميل — الحاوية تحافظ على البرودة ولا تسحب الحرارة.` },
    { ok: true, en: "Relative humidity 85–90 %; fresh-air vent ~15–25 m³/h to remove CO₂ and volatiles.", ar: "رطوبة نسبية 85–90%؛ فتحة هواء متجدد ~15–25 م³/س لطرد ثاني أكسيد الكربون والمواد المتطايرة." },
    { ok: true, en: "Ventilated corrugated cartons (open-top telescopic, ~15 kg), vent holes aligned with pallet airflow; do not block the T-bar floor.", ar: "كراتين مضلعة مهواة (~15 كجم)، فتحات التهوية على خط سريان الهواء في البالتة؛ لا تسد أرضية الحاوية." },
    { ok: wood, en: wood ? "Wooden pallets must carry the ISPM-15 mark (heat-treated)." : "Plastic pallets: no ISPM-15 requirement — check they are clean and food-grade.", ar: wood ? "البالتات الخشبية لازم عليها علامة ISPM-15 (معالجة حراريًا)." : "بالتات بلاستيك: لا تحتاج ISPM-15 — اتأكد إنها نظيفة ومناسبة للغذاء." },
    { ok: !mixed, en: mixed ? "Mixed load: do NOT share the container with ethylene producers or commodities treated with volatile chemicals — residues can migrate into citrus (a known cross-contamination route)." : "Dedicated citrus load — lowest cross-contamination risk.", ar: mixed ? "حمولة مختلطة: لا تشارك الحاوية مع منتجات مُنتجة للإيثيلين أو معاملة بمواد متطايرة — المتبقيات ممكن تنتقل للموالح (طريق معروف للتلوث العرضي)." : "حمولة موالح فقط — أقل خطر للتلوث العرضي." },
    { ok: true, en: "Waxes/coatings: use only EU-authorised food additives for citrus surface treatment, and declare post-harvest treatments (e.g. preservatives, waxes) on the carton label.", ar: "الشموع/التغليف: استخدم فقط الإضافات الغذائية المصرح بها أوروبيًا لمعاملة سطح الموالح، واكتب معاملات ما بعد الحصاد (مواد حافظة، شمع) على ملصق الكرتونة." },
    { ok: transit <= 25, en: transit > 25 ? `Transit ${transit} days is long: consider controlled atmosphere and verify the post-harvest fungicide program is within EU MRLs.` : `Transit ${transit} days — standard reefer settings are adequate.`, ar: transit > 25 ? `مدة النقل ${transit} يوم طويلة: فكّر في الجو المتحكم فيه واتأكد إن برنامج المبيدات الفطرية بعد الحصاد داخل الحدود الأوروبية.` : `مدة النقل ${transit} يوم — إعدادات التبريد القياسية كافية.` },
  ];
  if (degreened) tips.push({ ok: false, en: "De-greened fruit has a shorter shelf life — ship quickly and avoid temperatures below 4 °C (chilling injury).", ar: "الثمار المعاملة لإزالة اللون الأخضر عمرها أقصر — اشحن بسرعة وتجنب أقل من 4°م (أضرار البرودة)." });
  return (
    <div className="grid gap-6 lg:grid-cols-[340px_1fr]">
      <Card className="space-y-4 p-5">
        <Field label={tr("Variety", "الصنف")}>
          <select className={inputCls} value={variety} onChange={(e) => setVariety(e.target.value)}>
            <option value="Valencia">{tr("Valencia", "فالنسيا")}</option>
            <option value="Navel">{tr("Navel", "أبو سرة")}</option>
            <option value="Blood">{tr("Blood orange", "دموي")}</option>
          </select>
        </Field>
        <Field label={`${tr("Transit time (days)", "مدة النقل (يوم)")}: ${transit}`}>
          <input type="range" min={3} max={40} value={transit} onChange={(e) => setTransit(+e.target.value)} className="w-full accent-citrus-500" />
        </Field>
        {[[mixed, setMixed, tr("Mixed load with other produce", "حمولة مختلطة مع منتجات أخرى")], [degreened, setDegreened, tr("Fruit was de-greened", "الثمار معاملة لإزالة اللون الأخضر")], [wood, setWood, tr("Wooden pallets", "بالتات خشب")]].map(([v, s, l], i) => (
          <label key={i} className="flex items-center gap-2 text-sm font-semibold"><input type="checkbox" className="h-4 w-4 accent-citrus-500" checked={v as boolean} onChange={(e) => (s as (b: boolean) => void)(e.target.checked)} />{l as string}</label>
        ))}
      </Card>
      <div>
        <div className="mb-4 grid gap-3 sm:grid-cols-4">
          {[[ThermometerSnowflake, temp, tr("Set point", "درجة الضبط")], [Droplets, "85–90%", tr("Humidity", "الرطوبة")], [Wind, "15–25 m³/h", tr("Fresh air", "هواء متجدد")], [Box, "40' HC RF", tr("Container", "الحاوية")]].map(([I, v, l], i) => {
            const Icon = I as typeof Box;
            return <Card key={i} className="p-4"><Icon className="mb-2 h-5 w-5 text-leaf-600" /><div className="font-display text-lg font-black" dir="ltr">{v as string}</div><div className="text-xs text-ink-700/70 dark:text-sand-200/60">{l as string}</div></Card>;
          })}
        </div>
        <Card className="p-5">
          <ul className="space-y-3 text-sm">
            {tips.map((t, i) => (
              <li key={i} className="flex gap-3">{t.ok ? <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-ok" /> : <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-warn" />}<span>{tr(t.en, t.ar)}</span></li>
            ))}
          </ul>
          <p className="mt-5 text-[11px] text-ink-700/60 dark:text-sand-200/50">{tr("General guidance for orange reefer shipments; follow your shipping line's and buyer's specifications.", "إرشادات عامة لشحن البرتقال مبردًا؛ التزم بمواصفات الخط الملاحي والمستورد.")}</p>
        </Card>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Carbon footprint (indicative)                                       */
/* ------------------------------------------------------------------ */
const PORTS: { id: string; en: string; ar: string; km: number }[] = [
  { id: "RTM", en: "Rotterdam (NL)", ar: "روتردام (هولندا)", km: 5800 },
  { id: "ANR", en: "Antwerp (BE)", ar: "أنتويرب (بلجيكا)", km: 5900 },
  { id: "HAM", en: "Hamburg (DE)", ar: "هامبورج (ألمانيا)", km: 6500 },
  { id: "VLC", en: "Valencia (ES)", ar: "فالنسيا (إسبانيا)", km: 2900 },
  { id: "MRS", en: "Marseille (FR)", ar: "مارسيليا (فرنسا)", km: 2500 },
  { id: "GOA", en: "Genoa (IT)", ar: "جنوة (إيطاليا)", km: 2300 },
  { id: "PIR", en: "Piraeus (GR)", ar: "بيرايوس (اليونان)", km: 1000 },
];
// indicative well-to-wheel factors, kg CO2e per tonne-km
const F = { truck: 0.105, reeferSea: 0.025, air: 0.8 };

function Carbon() {
  const { tr, lang, num } = useLang();
  const [tons, setTons] = useState(24);
  const [port, setPort] = useState("RTM");
  const [road, setRoad] = useState(220);
  const [inland, setInland] = useState(150);
  const [mode, setMode] = useState<"sea" | "air">("sea");
  const p = PORTS.find((x) => x.id === port)!;
  const legs = [
    { en: "Farm → Egyptian port (truck)", ar: "المزرعة ← الميناء المصري (شاحنة)", kg: tons * road * F.truck },
    mode === "sea"
      ? { en: `Alexandria → ${p.en} (reefer ship)`, ar: `الإسكندرية ← ${p.ar} (سفينة مبردة)`, kg: tons * p.km * F.reeferSea }
      : { en: `Cairo → ${p.en.split(" (")[0]} (air freight)`, ar: `القاهرة ← ${p.ar.split(" (")[0]} (شحن جوي)`, kg: tons * p.km * 0.75 * F.air },
    { en: "EU port → distribution centre (truck)", ar: "الميناء الأوروبي ← مركز التوزيع (شاحنة)", kg: tons * inland * F.truck },
  ];
  const total = legs.reduce((a, l) => a + l.kg, 0);
  const max = Math.max(...legs.map((l) => l.kg));
  return (
    <div className="grid gap-6 lg:grid-cols-[340px_1fr]">
      <Card className="space-y-4 p-5">
        <Field label={tr("Shipment (tonnes)", "الشحنة (طن)")}><input className={inputCls} type="number" min="1" value={tons} onChange={(e) => setTons(Math.max(0, +e.target.value))} /></Field>
        <Field label={tr("Mode", "وسيلة النقل")}>
          <select className={inputCls} value={mode} onChange={(e) => setMode(e.target.value as "sea" | "air")}>
            <option value="sea">{tr("Sea — reefer container", "بحري — حاوية مبردة")}</option>
            <option value="air">{tr("Air freight", "شحن جوي")}</option>
          </select>
        </Field>
        <Field label={tr("Destination port", "ميناء الوصول")}>
          <select className={inputCls} value={port} onChange={(e) => setPort(e.target.value)}>
            {PORTS.map((x) => <option key={x.id} value={x.id}>{lang === "ar" ? x.ar : x.en} · ~{x.km.toLocaleString()} km</option>)}
          </select>
        </Field>
        <Field label={tr("Farm → port (km)", "المزرعة ← الميناء (كم)")}><input className={inputCls} type="number" min="0" value={road} onChange={(e) => setRoad(+e.target.value)} /></Field>
        <Field label={tr("EU port → DC (km)", "الميناء الأوروبي ← مركز التوزيع (كم)")}><input className={inputCls} type="number" min="0" value={inland} onChange={(e) => setInland(+e.target.value)} /></Field>
      </Card>
      <Card className="p-6">
        <div className="text-xs font-bold uppercase tracking-wider text-ink-600/60 dark:text-sand-300/60">{tr("Estimated transport emissions", "الانبعاثات التقديرية للنقل")}</div>
        <div className="mt-1 flex flex-wrap items-baseline gap-3">
          <span className="font-display text-5xl font-black text-leaf-700 dark:text-leaf-300">{num(total / 1000, 2)}</span>
          <span className="text-lg font-semibold">{tr("t CO₂e", "طن مكافئ CO₂")}</span>
          <span className="text-sm text-ink-700/70 dark:text-sand-200/60">· {num(tons ? total / tons : 0, 1)} {tr("kg CO₂e per tonne of oranges", "كجم لكل طن برتقال")}</span>
        </div>
        <div className="mt-6 space-y-4">
          {legs.map((l, i) => (
            <div key={i}>
              <div className="mb-1 flex justify-between text-sm"><span>{tr(l.en, l.ar)}</span><b>{num(l.kg, 0)} kg</b></div>
              <div className="h-3 overflow-hidden rounded-full bg-sand-100 dark:bg-ink-800"><div className="h-full rounded-full bg-leaf-500" style={{ width: `${max ? (l.kg / max) * 100 : 0}%` }} /></div>
            </div>
          ))}
        </div>
        {mode === "air" && <div className="mt-5 rounded-lg bg-amber-50 p-3 text-sm text-amber-900 dark:bg-amber-950/40 dark:text-amber-200">{tr("Air freight emits roughly 30× more per tonne-km than reefer shipping.", "الشحن الجوي بيطلع انبعاثات تقريبًا 30 ضعف الشحن البحري المبرد لكل طن-كم.")}</div>}
        <p className="mt-6 text-[11px] leading-relaxed text-ink-700/60 dark:text-sand-200/50">
          {tr(
            `Indicative factors (kg CO₂e/t·km): truck ${F.truck}, reefer ship ${F.reeferSea}, air ${F.air}. Sea distances are approximate. Production version: GLEC Framework / ISO 14083 methodology with carrier-specific data.`,
            `معاملات تقديرية (كجم CO₂e/طن·كم): شاحنة ${F.truck}، سفينة مبردة ${F.reeferSea}، جوي ${F.air}. المسافات البحرية تقريبية. النسخة النهائية: منهجية GLEC / ISO 14083 ببيانات الناقل.`
          )}
        </p>
      </Card>
    </div>
  );
}
