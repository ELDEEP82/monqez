import { Printer, X } from "lucide-react";
import { EU_COUNTRIES, useLang } from "../lang";
import { Batch, REG_LABEL, Result } from "../engine";
import { LEVEL_STYLE, LevelChip, Logo } from "../ui";
import { META } from "../data";

export default function Report({ batch: b, res, onClose }: { batch: Batch; res: Result; onClose: () => void }) {
  const { tr, bi, lang, num } = useLang();
  const country = EU_COUNTRIES.find((c) => c.code === b.destination);
  const flagged = res.items.filter((i) => i.level !== "green");
  const notes = [
    tr("This report is based exclusively on European Union regulations — Reg. (EC) No 396/2005 (MRLs) and Reg. (EC) No 1107/2009 (approval of active substances). EU MRLs are harmonised and apply identically in all 27 member states.", "هذا التقرير مبني حصريًا على تشريعات الاتحاد الأوروبي — اللائحة 396/2005 (الحدود القصوى للمتبقيات) واللائحة 1107/2009 (اعتماد المواد الفعالة). الحدود الأوروبية موحّدة وتُطبق بنفس الشكل في كل الدول الأعضاء الـ27."),
    tr("Other markets (e.g. USA, UK, Gulf states) set different limits; this result does not apply to them.", "الأسواق الأخرى (مثل أمريكا وبريطانيا ودول الخليج) لها حدود مختلفة؛ هذه النتيجة لا تنطبق عليها."),
    tr("Some substances used post-harvest or during storage (fungicides, sprout inhibitors, fumigants, waxes) may be banned in the EU even if registered in Egypt. Any substance applied after the lab sample was taken is not reflected in the lab report.", "بعض المواد المستخدمة بعد الحصاد أو أثناء التخزين (مبيدات فطرية، مثبطات تزريع، مواد تبخير، شموع) قد تكون محظورة في الاتحاد الأوروبي حتى لو مسجلة في مصر. أي مادة استُخدمت بعد أخذ عينة المعمل لا تظهر في تقريره."),
    tr("Mixing a permitted product with a non-permitted one — even at a very small share — can produce a violation.", "خلط مادة مسموحة بأخرى غير مسموحة — حتى بنسبة ضئيلة جدًا — ممكن يسبب مخالفة."),
    tr("Risk is a compliance (border-rejection) estimate, not a toxicological risk assessment. An MRL exceedance does not automatically imply a health risk; the exceedance ratio (residue ÷ MRL) is a simplified indicator devised for this tool, not an official EFSA/RASFF metric.", "الخطر هنا تقدير للمطابقة (رفض على الحدود) وليس تقييمًا للسمية. تخطي الحد لا يعني تلقائيًا خطرًا صحيًا؛ ونسبة التخطي (المتبقي ÷ الحد) مؤشر مبسط خاص بهذه الأداة وليست مقياسًا رسميًا لـEFSA/RASFF."),
    tr("Cross-contamination during shared storage or transport cannot be predicted from spray records. Monqez does not replace laboratory testing or official border controls.", "التلوث العرضي أثناء التخزين أو النقل المشترك لا يمكن التنبؤ به من سجلات الرش. منقذ لا يغني عن التحليل المعملي أو الرقابة الرسمية على الحدود."),
  ];
  return (
    <div className="fixed inset-0 z-50 overflow-auto bg-ink-950/70 p-0 backdrop-blur-sm sm:p-6 print:static print:bg-white print:p-0">
      <div className="no-print sticky top-0 z-10 mx-auto flex max-w-4xl justify-end gap-2 p-3">
        <button onClick={() => window.print()} className="flex items-center gap-2 rounded-xl bg-citrus-500 px-4 py-2 text-sm font-semibold text-white shadow-lg"><Printer className="h-4 w-4" />{tr("Print / Save PDF", "طباعة / حفظ PDF")}</button>
        <button onClick={onClose} className="rounded-xl bg-white p-2 text-ink-900 shadow-lg" aria-label="close"><X className="h-5 w-5" /></button>
      </div>
      <article className="print-area mx-auto max-w-4xl bg-white p-6 text-ink-900 shadow-2xl sm:rounded-2xl sm:p-10">
        <header className="flex flex-wrap items-start justify-between gap-4 border-b-2 border-ink-900 pb-5">
          <div className="flex items-center gap-3">
            <Logo size={48} />
            <div>
              <div className="font-display text-2xl font-black">{tr("Monqez — Compliance Report", "منقذ — تقرير المطابقة")}</div>
              <div className="text-xs text-ink-700">{tr("EU pesticide MRL pre-screening · Oranges (0110020)", "فحص مسبق لحدود متبقيات المبيدات الأوروبية · برتقال (0110020)")}</div>
            </div>
          </div>
          <div className="text-xs text-ink-700 ltr:text-right rtl:text-left">
            <div><b>{tr("Batch", "الشحنة")}:</b> <span dir="ltr">{b.batchCode}</span></div>
            <div><b>{tr("Issued", "تاريخ الإصدار")}:</b> {new Date().toLocaleString(lang === "ar" ? "ar-EG" : "en-GB")}</div>
          </div>
        </header>

        <section className="mt-5 grid gap-3 text-sm sm:grid-cols-4">
          {[
            [tr("Exporter", "المصدّر"), b.exporter || "—"],
            [tr("Variety", "الصنف"), b.variety],
            [tr("Destination", "الوجهة"), `${lang === "ar" ? country?.ar : country?.en} (EU)`],
            [tr("Quantity", "الكمية"), `${b.tons || "—"} ${tr("t", "طن")}`],
            [tr("Harvest", "الحصاد"), b.harvestDate || "—"],
            [tr("Shipping", "الشحن"), b.shipDate || "—"],
            [tr("Packhouse", "محطة التعبئة"), b.packhouse || "—"],
            [tr("Lab", "المعمل"), b.labName ? `${b.labName}${b.sampleDate ? ` · ${b.sampleDate}` : ""}` : "—"],
          ].map(([k, v]) => (
            <div key={k} className="rounded-lg bg-sand-100 p-2.5">
              <div className="text-[10px] font-semibold uppercase text-ink-600">{k}</div>
              <div className="font-semibold">{v}</div>
            </div>
          ))}
        </section>

        <section className={`mt-5 flex flex-wrap items-center justify-between gap-4 rounded-xl p-5 ring-2 ${LEVEL_STYLE[res.level].ring}`}>
          <div>
            <div className="text-xs font-semibold uppercase text-ink-600">{tr("Overall verdict", "النتيجة الإجمالية")}</div>
            <div className="mt-1"><LevelChip level={res.level} big /></div>
          </div>
          <div className="text-center">
            <div className="text-xs font-semibold uppercase text-ink-600">{tr("Probability of clearing", "احتمالية العبور")}</div>
            <div className={`font-display text-4xl font-black ${LEVEL_STYLE[res.level].text}`}>{num(Math.round(res.pClear * 100))}%</div>
          </div>
          <div className="text-center">
            <div className="text-xs font-semibold uppercase text-ink-600">{tr("Substances checked", "مواد تم فحصها")}</div>
            <div className="font-display text-4xl font-black">{num(res.items.length)}</div>
          </div>
        </section>

        <section className="mt-6">
          <h3 className="mb-2 font-display text-lg font-bold">{tr("Assessment table", "جدول التقييم")}</h3>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px] border-collapse text-xs">
              <thead>
                <tr className="bg-ink-900 text-white">
                  {[tr("Product", "المنتج"), tr("Active substance", "المادة الفعالة"), tr("EU status", "الحالة"), tr("MRL mg/kg", "الحد مجم/كجم"), tr("Δt / PHI", "الفترة / الأمان"), tr("Lab", "المعمل"), tr("Risk", "الخطر")].map((h) => (
                    <th key={h} className="p-2 text-start font-semibold">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {res.items.map((it) => (
                  <tr key={it.key} className="border-b border-sand-200 align-top">
                    <td className="p-2 font-semibold">{lang === "ar" ? it.productAr : it.productEn}</td>
                    <td className="p-2" dir="ltr">{it.subName}</td>
                    <td className="p-2">{bi(REG_LABEL[it.regClass])}{it.bannedSince ? <div className="text-[10px] text-bad">{tr("not approved since", "غير معتمد منذ")} {it.bannedSince}</div> : null}</td>
                    <td className="p-2 font-mono" dir="ltr">{it.mrl?.raw ?? (it.regClass === "annexIV" ? "n/r" : "0.01")}</td>
                    <td className="p-2" dir="ltr">{it.dt != null ? `${it.dt}d / ${it.phi ?? "—"}d` : "—"}</td>
                    <td className="p-2" dir="ltr">{it.lab ? (it.lab.nd ? "ND" : `${it.lab.value} (${Math.round((it.lab.ratio ?? 0) * 100)}%)`) : "—"}</td>
                    <td className="p-2"><span className={`inline-flex items-center gap-1 font-bold ${LEVEL_STYLE[it.level].text}`}><span className={`h-2 w-2 rounded-full ${LEVEL_STYLE[it.level].dot}`} />{num(Math.round(it.p * 100))}%</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {flagged.length > 0 && (
          <section className="mt-6">
            <h3 className="mb-2 font-display text-lg font-bold">{tr("What went wrong and what to do", "إيه المشكلة وتعمل إيه")}</h3>
            <div className="space-y-3">
              {flagged.map((it) => (
                <div key={it.key} className="break-inside-avoid rounded-xl border border-sand-200 p-3 text-sm">
                  <div className="mb-1 flex flex-wrap items-center gap-2 font-semibold">{lang === "ar" ? it.productAr : it.productEn} <span className="text-xs font-normal text-ink-600" dir="ltr">({it.subName})</span> <LevelChip level={it.level} /></div>
                  <ul className="list-disc space-y-1 ps-5 text-ink-800">
                    {it.reasons.map((r, i) => <li key={i}>{bi(r)}</li>)}
                  </ul>
                  {it.alternatives.length > 0 && (
                    <div className="mt-2 text-xs"><b className="text-leaf-700">{tr("Compliant alternatives:", "بدائل مطابقة:")}</b> {it.alternatives.map((a) => `${lang === "ar" ? a.ar : a.en} (${a.ai.map((x) => x.substance.split(" (")[0]).join(" + ")}, PHI ${a.phi})`).join(" · ")}</div>
                  )}
                </div>
              ))}
            </div>
          </section>
        )}

        <section className="mt-6 rounded-xl bg-sand-100 p-4">
          <h3 className="mb-2 font-display text-base font-bold">{tr("Important notes", "ملاحظات مهمة")}</h3>
          <ol className="list-decimal space-y-1.5 ps-5 text-xs leading-relaxed text-ink-800">
            {notes.map((n, i) => <li key={i}>{n}</li>)}
          </ol>
        </section>

        <footer className="mt-6 border-t border-sand-200 pt-3 text-[10px] leading-relaxed text-ink-600">
          {tr("Data", "البيانات")}: {META.mrlFile} · {META.asFile}. {tr("Trade-name/PHI map is an indicative demo sample pending the Egyptian APC registry. Generated by Monqez prototype v0.1.", "ربط الأسماء التجارية وفترات الأمان عينة توضيحية لحين ربط سجل لجنة المبيدات المصرية. صادر عن النموذج الأولي لمنقذ v0.1.")}
        </footer>
      </article>
    </div>
  );
}
