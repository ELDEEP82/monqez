import { useEffect, useMemo, useState } from "react";
import { Plus, Trash2, Sprout, Warehouse, FlaskConical, ClipboardList, Save, FileText, RotateCcw, Wand2, ChevronDown, AlertTriangle, Info, Check as CheckIcon } from "lucide-react";
import { EU_COUNTRIES, store, useLang } from "../lang";
import { Batch, Item, OtherCategory, OtherTiming, REG_LABEL, Result, demoBatch, emptyBatch, evaluate, uid } from "../engine";
import { Btn, Card, Field, Gauge, LEVEL_STYLE, LevelChip, ProductPicker, inputCls } from "../ui";
import { subById, tradeById } from "../data";
import Report from "./Report";

export type Saved = { batch: Batch; savedAt: string; level: Result["level"]; pClear: number };

function readQuery() {
  const q = (location.hash.split("?")[1] || "").split("&").map((p) => p.split("="));
  return Object.fromEntries(q.filter((x) => x[0]));
}

const CATS: [OtherCategory, string, string][] = [
  ["postharvest_fungicide", "Post-harvest fungicide", "مبيد فطري بعد الحصاد"],
  ["insecticide", "Insecticide / acaricide", "مبيد حشري / أكاروسي"],
  ["growth_regulator", "Growth regulator", "منظم نمو"],
  ["storage", "Storage treatment", "معاملة أثناء التخزين"],
  ["wax", "Wax / coating", "شمع / تغليف"],
  ["other", "Other substance", "مادة أخرى"],
];
const TIMINGS: [OtherTiming, string, string][] = [
  ["before_sampling", "Before lab sampling", "قبل أخذ عينة المعمل"],
  ["after_sampling", "After lab sampling", "بعد أخذ عينة المعمل"],
  ["storage", "During storage", "أثناء التخزين"],
  ["mixture", "Tank-mixed with another product", "مخلوط مع منتج آخر"],
];

function Section({ icon: Icon, title, sub, children, n, right }: { icon: typeof Sprout; title: string; sub: string; children: React.ReactNode; n: number; right?: React.ReactNode }) {
  const { num } = useLang();
  return (
    <Card className="p-4 sm:p-6">
      <div className="mb-5 flex items-start gap-3">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-leaf-50 text-leaf-700 dark:bg-ink-800 dark:text-leaf-300">
          <Icon className="h-5 w-5" />
        </div>
        <div className="min-w-0 flex-1">
          <div className="text-[11px] font-bold text-citrus-600">{num(n)} / {num(4)}</div>
          <h3 className="font-display text-lg font-bold leading-tight">{title}</h3>
          <p className="mt-0.5 text-xs text-ink-700/70 dark:text-sand-200/60">{sub}</p>
        </div>
        {right}
      </div>
      {children}
    </Card>
  );
}

export default function Check() {
  const { tr, lang, num, bi } = useLang();
  const [b, setB] = useState<Batch>(() => store.get<Batch>("mq-draft", emptyBatch()));
  const [showReport, setShowReport] = useState(false);
  const [saved, setSaved] = useState(false);
  const [open, setOpen] = useState<string | null>(null);

  useEffect(() => {
    const q = readQuery();
    if (q.demo === "risky" || q.demo === "clean") setB(demoBatch(q.demo));
    if (q.id) {
      const h = store.get<Saved[]>("mq-history", []).find((x) => x.batch.id === q.id);
      if (h) setB(h.batch);
    }
  }, []);
  useEffect(() => store.set("mq-draft", b), [b]);

  const res = useMemo(() => evaluate(b), [b]);
  const hasInput = res.items.length > 0;
  const set = <K extends keyof Batch>(k: K, v: Batch[K]) => { setB((p) => ({ ...p, [k]: v })); setSaved(false); };

  const save = () => {
    const h = store.get<Saved[]>("mq-history", []).filter((x) => x.batch.id !== b.id);
    h.unshift({ batch: b, savedAt: new Date().toISOString(), level: res.level, pClear: res.pClear });
    store.set("mq-history", h.slice(0, 50));
    setSaved(true);
  };

  const verdict =
    res.level === "green"
      ? tr("Batch is likely to clear EU border checks.", "الشحنة غالبًا هتعدّي فحص الحدود الأوروبية.")
      : res.level === "yellow"
      ? tr("Borderline — run a targeted pre-export lab test before shipping.", "حالة حدّية — اعمل تحليل معمل موجّه قبل الشحن.")
      : tr("High risk of rejection — do not ship before resolving the red items.", "خطر رفض مرتفع — لا تشحن قبل حل البنود الحمراء.");

  return (
    <div className="mx-auto max-w-7xl px-4 pb-24 pt-8 sm:px-6 sm:py-10 lg:pb-10">
      <div className="no-print mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="mb-1 text-xs font-bold uppercase tracking-[.18em] text-citrus-600">{tr("Compliance engine", "محرك المطابقة")}</div>
          <h1 className="font-display text-3xl font-extrabold">{tr("Batch pre-screening", "الفحص المسبق للشحنة")}</h1>
          <p className="mt-1 text-sm text-ink-700/75 dark:text-sand-200/70">{tr("Results update live as you type. Crop: oranges (0110020) · Destination: EU (harmonised MRLs).", "النتيجة بتتحدث مباشرة مع الإدخال. المحصول: برتقال (0110020) · الوجهة: الاتحاد الأوروبي (حدود موحّدة).")}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Btn variant="soft" onClick={() => { setB(demoBatch("risky")); setSaved(false); }}><Wand2 className="h-4 w-4" />{tr("Risky demo", "مثال خطر")}</Btn>
          <Btn variant="soft" onClick={() => { setB(demoBatch("clean")); setSaved(false); }}><Wand2 className="h-4 w-4" />{tr("Clean demo", "مثال سليم")}</Btn>
          <Btn variant="ghost" onClick={() => { setB(emptyBatch()); setSaved(false); }}><RotateCcw className="h-4 w-4" />{tr("New", "جديد")}</Btn>
        </div>
      </div>

      <div className="no-print grid gap-6 lg:grid-cols-[1fr_360px]">
        <div className="space-y-5">
          {/* 1. batch info */}
          <Section n={1} icon={ClipboardList} title={tr("Batch information", "بيانات الشحنة")} sub={tr("Harvest date drives the PHI check.", "تاريخ الحصاد هو أساس حساب فترة الأمان.")}>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              <Field label={tr("Exporter / farm", "المصدّر / المزرعة")}><input className={inputCls} value={b.exporter} onChange={(e) => set("exporter", e.target.value)} /></Field>
              <Field label={tr("Batch code", "كود الشحنة")}><input className={inputCls} dir="ltr" value={b.batchCode} onChange={(e) => set("batchCode", e.target.value)} /></Field>
              <Field label={tr("Crop", "المحصول")}>
                <select className={inputCls} value="oranges" onChange={() => {}}>
                  <option value="oranges">{tr("Oranges (0110020)", "برتقال (0110020)")}</option>
                  <option disabled>{tr("Mandarins — coming soon", "يوسفي — قريبًا")}</option>
                  <option disabled>{tr("Grapes — coming soon", "عنب — قريبًا")}</option>
                  <option disabled>{tr("Strawberries — coming soon", "فراولة — قريبًا")}</option>
                </select>
              </Field>
              <Field label={tr("Variety", "الصنف")}>
                <select className={inputCls} value={b.variety} onChange={(e) => set("variety", e.target.value)}>
                  {["Valencia", "Navel", "Baladi", "Blood orange", "Other"].map((v) => <option key={v} value={v}>{lang === "ar" ? { Valencia: "فالنسيا", Navel: "أبو سرة", Baladi: "بلدي", "Blood orange": "دموي", Other: "أخرى" }[v] : v}</option>)}
                </select>
              </Field>
              <Field label={tr("EU destination", "دولة الوصول (الاتحاد الأوروبي)")} hint={tr("MRLs are harmonised across all 27 EU states.", "الحدود موحدة على كل دول الاتحاد الـ27.")}>
                <select className={inputCls} value={b.destination} onChange={(e) => set("destination", e.target.value)}>
                  {EU_COUNTRIES.map((c) => <option key={c.code} value={c.code}>{lang === "ar" ? c.ar : c.en}</option>)}
                  <option disabled>{tr("USA / UK / Gulf — coming soon", "أمريكا / بريطانيا / الخليج — قريبًا")}</option>
                </select>
              </Field>
              <Field label={tr("Quantity (tonnes)", "الكمية (طن)")}><input className={inputCls} type="number" min="0" value={b.tons} onChange={(e) => set("tons", e.target.value)} /></Field>
              <Field label={tr("Harvest date", "تاريخ الحصاد")}><input className={inputCls} type="date" value={b.harvestDate} onChange={(e) => set("harvestDate", e.target.value)} /></Field>
              <Field label={tr("Shipping date", "تاريخ الشحن")}><input className={inputCls} type="date" value={b.shipDate} onChange={(e) => set("shipDate", e.target.value)} /></Field>
              <Field label={tr("Packhouse", "محطة التعبئة")}><input className={inputCls} value={b.packhouse} onChange={(e) => set("packhouse", e.target.value)} /></Field>
            </div>
          </Section>

          {/* 2. spray program */}
          <Section n={2} icon={Sprout} title={tr("Pre-harvest spray program", "برنامج الرش قبل الحصاد")} sub={tr("Pick the trade name used in the field — PHI auto-fills from the label (editable).", "اختار الاسم التجاري المستخدم في الحقل — فترة الأمان بتتملى تلقائيًا من العبوة (قابلة للتعديل).")}>
            <div className="space-y-3">
              {b.sprays.map((r, i) => (
                <div key={r.uid} className="grid gap-3 rounded-xl border border-sand-200 bg-sand-50/60 p-3 sm:grid-cols-[1.6fr_1fr_.9fr_.6fr_auto] dark:border-ink-700 dark:bg-ink-950/50">
                  <Field label={tr("Product", "المنتج")}>
                    <ProductPicker value={r.ref} onChange={(ref) => {
                      const phi = ref?.kind === "trade" ? tradeById.get(ref.id)!.phi : r.phi;
                      const rate = ref?.kind === "trade" && !r.rate ? tradeById.get(ref.id)!.rate : r.rate;
                      set("sprays", b.sprays.map((x) => (x.uid === r.uid ? { ...x, ref, phi, rate } : x)));
                    }} />
                  </Field>
                  <Field label={tr("Last application", "تاريخ آخر رشة")}><input className={inputCls} type="date" value={r.date} onChange={(e) => set("sprays", b.sprays.map((x) => (x.uid === r.uid ? { ...x, date: e.target.value } : x)))} /></Field>
                  <Field label={tr("Rate", "المعدل")}><input className={inputCls} value={r.rate} onChange={(e) => set("sprays", b.sprays.map((x) => (x.uid === r.uid ? { ...x, rate: e.target.value } : x)))} /></Field>
                  <Field label={tr("PHI (days)", "فترة الأمان")}><input className={inputCls} type="number" min="0" value={r.phi} onChange={(e) => set("sprays", b.sprays.map((x) => (x.uid === r.uid ? { ...x, phi: e.target.value === "" ? "" : Number(e.target.value) } : x)))} /></Field>
                  <button aria-label="remove" onClick={() => set("sprays", b.sprays.filter((x) => x.uid !== r.uid))} className="self-end rounded-lg p-2.5 text-ink-600/60 hover:bg-red-50 hover:text-bad dark:hover:bg-red-950/40">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              ))}
              <Btn variant="soft" onClick={() => set("sprays", [...b.sprays, { uid: uid(), ref: null, date: "", rate: "", phi: "" }])}><Plus className="h-4 w-4" />{tr("Add spray", "أضف رشة")}</Btn>
            </div>
          </Section>

          {/* 3. other substances */}
          <Section n={3} icon={Warehouse} title={tr("Post-harvest, storage & other substances", "مواد ما بعد الحصاد والتخزين ومواد أخرى")} sub={tr("Fungicides in the packhouse, growth regulators, storage treatments, waxes, mixtures — anything that touched the fruit, including after the lab sample was taken.", "مبيدات فطرية في محطة التعبئة، منظمات نمو، معاملات تخزين، شموع، خلطات — أي مادة لمست الثمار، حتى لو بعد أخذ عينة المعمل.")}>
            <div className="space-y-3">
              {b.others.length === 0 && <div className="rounded-xl border border-dashed border-sand-300 p-4 text-center text-sm text-ink-700/60 dark:border-ink-600 dark:text-sand-200/50">{tr("No substances added yet.", "لم تتم إضافة مواد بعد.")}</div>}
              {b.others.map((r) => (
                <div key={r.uid} className="grid gap-3 rounded-xl border border-sand-200 bg-sand-50/60 p-3 sm:grid-cols-2 lg:grid-cols-[1fr_1.4fr_1fr_auto] dark:border-ink-700 dark:bg-ink-950/50">
                  <Field label={tr("Type", "النوع")}>
                    <select className={inputCls} value={r.category} onChange={(e) => set("others", b.others.map((x) => (x.uid === r.uid ? { ...x, category: e.target.value as OtherCategory } : x)))}>
                      {CATS.map(([v, en, ar]) => <option key={v} value={v}>{lang === "ar" ? ar : en}</option>)}
                    </select>
                  </Field>
                  <Field label={tr("Product / substance", "المنتج / المادة")}>
                    <ProductPicker value={r.ref} onChange={(ref) => set("others", b.others.map((x) => (x.uid === r.uid ? { ...x, ref } : x)))} />
                  </Field>
                  <Field label={tr("When was it used?", "استُخدم امتى؟")}>
                    <select className={inputCls} value={r.timing} onChange={(e) => set("others", b.others.map((x) => (x.uid === r.uid ? { ...x, timing: e.target.value as OtherTiming } : x)))}>
                      {TIMINGS.map(([v, en, ar]) => <option key={v} value={v}>{lang === "ar" ? ar : en}</option>)}
                    </select>
                  </Field>
                  <button aria-label="remove" onClick={() => set("others", b.others.filter((x) => x.uid !== r.uid))} className="self-end rounded-lg p-2.5 text-ink-600/60 hover:bg-red-50 hover:text-bad dark:hover:bg-red-950/40">
                    <Trash2 className="h-4 w-4" />
                  </button>
                  {r.timing === "mixture" && (
                    <div className="sm:col-span-2 lg:col-span-4">
                      <Field label={tr("Mixed with (name, even at a tiny share)", "مخلوط مع (الاسم، حتى لو بنسبة ضئيلة)")}>
                        <input className={inputCls} value={r.mixedWith} onChange={(e) => set("others", b.others.map((x) => (x.uid === r.uid ? { ...x, mixedWith: e.target.value } : x)))} />
                      </Field>
                    </div>
                  )}
                </div>
              ))}
              <Btn variant="soft" onClick={() => set("others", [...b.others, { uid: uid(), ref: null, category: "postharvest_fungicide", timing: "before_sampling", mixedWith: "", note: "" }])}><Plus className="h-4 w-4" />{tr("Add substance", "أضف مادة")}</Btn>
            </div>
          </Section>

          {/* 4. lab */}
          <Section n={4} icon={FlaskConical} title={tr("Residue lab report (optional)", "تقرير معمل المتبقيات (اختياري)")} sub={tr("Measured values replace estimates. Substances found by the lab but not declared are flagged as possible contamination.", "القيم المقاسة بتحل محل التقديرات. أي مادة يكتشفها المعمل وغير مسجلة بتتعلم كتلوث محتمل.")}>
            <div className="mb-4 grid gap-4 sm:grid-cols-2">
              <Field label={tr("Laboratory", "المعمل")}><input className={inputCls} value={b.labName} onChange={(e) => set("labName", e.target.value)} /></Field>
              <Field label={tr("Sampling date", "تاريخ أخذ العينة")}><input className={inputCls} type="date" value={b.sampleDate} onChange={(e) => set("sampleDate", e.target.value)} /></Field>
            </div>
            <div className="space-y-3">
              {b.labs.map((r) => (
                <div key={r.uid} className="grid gap-3 rounded-xl border border-sand-200 bg-sand-50/60 p-3 sm:grid-cols-[1.6fr_.8fr_auto_auto] dark:border-ink-700 dark:bg-ink-950/50">
                  <Field label={tr("Active substance detected", "المادة الفعالة المكتشفة")}>
                    <ProductPicker subsOnly value={r.sid != null ? { kind: "sub", id: r.sid } : null} onChange={(ref) => set("labs", b.labs.map((x) => (x.uid === r.uid ? { ...x, sid: ref && ref.kind === "sub" ? ref.id : null } : x)))} placeholder={tr("Type substance name…", "اكتب اسم المادة…")} />
                  </Field>
                  <Field label={tr("Result (mg/kg)", "النتيجة (مجم/كجم)")}><input className={inputCls} type="number" step="0.001" min="0" disabled={r.nd} value={r.value} onChange={(e) => set("labs", b.labs.map((x) => (x.uid === r.uid ? { ...x, value: e.target.value } : x)))} /></Field>
                  <label className="flex items-center gap-2 self-end pb-3 text-xs font-semibold">
                    <input type="checkbox" checked={r.nd} onChange={(e) => set("labs", b.labs.map((x) => (x.uid === r.uid ? { ...x, nd: e.target.checked } : x)))} className="h-4 w-4 accent-citrus-500" />
                    {tr("Not detected", "لم يُكتشف")}
                  </label>
                  <button aria-label="remove" onClick={() => set("labs", b.labs.filter((x) => x.uid !== r.uid))} className="self-end rounded-lg p-2.5 text-ink-600/60 hover:bg-red-50 hover:text-bad dark:hover:bg-red-950/40">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              ))}
              <Btn variant="soft" onClick={() => set("labs", [...b.labs, { uid: uid(), sid: null, value: "", nd: false }])}><Plus className="h-4 w-4" />{tr("Add lab result", "أضف نتيجة معمل")}</Btn>
            </div>
          </Section>
        </div>

        {/* LIVE RESULT */}
        <aside className="lg:sticky lg:top-20 lg:self-start">
          <Card className="overflow-hidden">
            <div className={`h-1.5 ${hasInput ? LEVEL_STYLE[res.level].dot : "bg-sand-200 dark:bg-ink-700"}`} />
            <div className="p-5">
              <div className="mb-1 text-xs font-bold uppercase tracking-wider text-ink-600/60 dark:text-sand-300/60">{tr("Probability of clearing EU border", "احتمالية عبور الحدود الأوروبية")}</div>
              {hasInput ? (
                <>
                  <div className="flex justify-center"><Gauge value={res.pClear} level={res.level} /></div>
                  <div className="-mt-1 flex justify-center"><LevelChip level={res.level} big /></div>
                  <p className="mt-3 text-center text-sm font-semibold leading-snug">{verdict}</p>
                  <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                    {(["red", "yellow", "green"] as const).map((l) => (
                      <div key={l} className="rounded-xl bg-sand-100 py-2 dark:bg-ink-800">
                        <div className={`font-display text-xl font-black ${LEVEL_STYLE[l].text}`}>{num(res.counts[l])}</div>
                        <div className="text-[10px] font-semibold text-ink-600/70 dark:text-sand-300/60">{l === "red" ? tr("High risk", "خطر") : l === "yellow" ? tr("Caution", "تحذير") : tr("Safe", "آمن")}</div>
                      </div>
                    ))}
                  </div>
                </>
              ) : (
                <div className="py-10 text-center text-sm text-ink-700/60 dark:text-sand-200/50">{tr("Add at least one product to see the verdict.", "أضف منتج واحد على الأقل لعرض النتيجة.")}</div>
              )}
              {res.warnings.map((w, i) => (
                <div key={i} className="mt-3 flex gap-2 rounded-lg bg-amber-50 p-2.5 text-xs text-amber-900 dark:bg-amber-950/40 dark:text-amber-200"><AlertTriangle className="h-4 w-4 shrink-0" />{bi(w)}</div>
              ))}
              <div className="mt-5 grid grid-cols-2 gap-2">
                <Btn variant="dark" onClick={save} disabled={!hasInput}>{saved ? <CheckIcon className="h-4 w-4" /> : <Save className="h-4 w-4" />}{saved ? tr("Saved", "اتحفظت") : tr("Save", "حفظ")}</Btn>
                <Btn onClick={() => setShowReport(true)} disabled={!hasInput}><FileText className="h-4 w-4" />{tr("Report", "التقرير")}</Btn>
              </div>
            </div>
          </Card>
        </aside>
      </div>

      {/* DETAILED RESULTS */}
      {hasInput && (
        <div id="mq-results" className="no-print mt-8 scroll-mt-20">
          <h2 className="mb-4 font-display text-xl font-extrabold">{tr("Substance-by-substance assessment", "التقييم مادة بمادة")}</h2>
          <div className="space-y-3">
            {res.items.map((it) => <ItemRow key={it.key} it={it} open={open === it.key} onToggle={() => setOpen(open === it.key ? null : it.key)} />)}
          </div>
          {res.batchNotes.map((n, i) => (
            <div key={i} className="mt-3 flex gap-2 rounded-xl border border-leaf-200 bg-leaf-50 p-3 text-sm text-leaf-800 dark:border-leaf-700/40 dark:bg-leaf-700/10 dark:text-leaf-200"><Info className="mt-0.5 h-4 w-4 shrink-0" />{bi(n)}</div>
          ))}
        </div>
      )}

      {hasInput && (
        <div className="no-print fixed inset-x-0 bottom-0 z-30 border-t border-sand-200 bg-white/95 px-4 py-2.5 backdrop-blur lg:hidden dark:border-ink-700 dark:bg-ink-900/95">
          <div className="mx-auto flex max-w-xl items-center gap-3">
            <span className={`h-3 w-3 rounded-full ${LEVEL_STYLE[res.level].dot}`} />
            <div className="min-w-0 flex-1">
              <div className="text-[10px] font-semibold text-ink-600/70 dark:text-sand-300/60">{tr("Probability of clearing", "احتمالية العبور")}</div>
              <div dir="ltr" className={`font-display text-lg font-black leading-none ltr:text-left rtl:text-right ${LEVEL_STYLE[res.level].text}`}>{res.pClear > 0 && res.pClear < 0.01 ? "<1" : num(Math.round(res.pClear * 100))}%</div>
            </div>
            <Btn variant="soft" onClick={() => document.getElementById("mq-results")?.scrollIntoView({ behavior: "smooth" })}>{tr("Details", "التفاصيل")}</Btn>
            <Btn onClick={() => setShowReport(true)}><FileText className="h-4 w-4" /></Btn>
          </div>
        </div>
      )}

      {showReport && <Report batch={b} res={res} onClose={() => setShowReport(false)} />}
    </div>
  );
}

function ItemRow({ it, open, onToggle }: { it: Item; open: boolean; onToggle: () => void }) {
  const { tr, bi, lang, num } = useLang();
  const src = it.source === "spray" ? tr("Field spray", "رش حقلي") : it.source === "other" ? tr("Post-harvest / other", "بعد الحصاد / أخرى") : tr("Lab-only detection", "اكتشاف معملي فقط");
  return (
    <Card className={`overflow-hidden border-s-4 ${it.level === "red" ? "border-s-bad" : it.level === "yellow" ? "border-s-warn" : "border-s-ok"}`}>
      <button onClick={onToggle} className="flex w-full flex-wrap items-center gap-3 p-4 text-start">
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-display font-bold">{lang === "ar" ? it.productAr : it.productEn}</span>
            <span className="rounded bg-sand-100 px-1.5 py-0.5 text-[10px] font-semibold text-ink-700 dark:bg-ink-800 dark:text-sand-200">{src}</span>
          </div>
          <div className="mt-0.5 text-xs text-ink-700/70 dark:text-sand-200/60"><span dir="ltr">{it.subName}</span> · {bi(REG_LABEL[it.regClass])}</div>
        </div>
        <div className="flex w-full items-center justify-between gap-4 sm:w-auto sm:justify-end">
          <div className="text-end">
            <div className="text-[10px] uppercase text-ink-600/60 dark:text-sand-300/50">{tr("MRL", "الحد")}</div>
            <div className="font-mono text-sm" dir="ltr">{it.mrl?.raw ?? (it.regClass === "annexIV" ? "—" : "0.01")}</div>
          </div>
          <div className="text-end">
            <div className="text-[10px] uppercase text-ink-600/60 dark:text-sand-300/50">{tr("Risk", "الخطر")}</div>
            <div className={`font-display text-lg font-black ${LEVEL_STYLE[it.level].text}`}>{num(Math.round(it.p * 100))}%</div>
          </div>
          <LevelChip level={it.level} />
          <ChevronDown className={`h-4 w-4 transition ${open ? "rotate-180" : ""}`} />
        </div>
      </button>
      {open && (
        <div className="border-t border-sand-200 bg-sand-50/60 p-4 text-sm dark:border-ink-700 dark:bg-ink-950/40">
          <ul className="space-y-1.5">
            {it.reasons.map((r, i) => (
              <li key={i} className="flex gap-2"><span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-ink-600" />{bi(r)}</li>
            ))}
          </ul>
          <div className="mt-3 grid gap-2 text-xs sm:grid-cols-4">
            <Kv k={tr("EU status", "الحالة الأوروبية")} v={it.sub?.status ?? "—"} />
            <Kv k={tr("Approval expiry / ban date", "انتهاء الاعتماد / تاريخ الحظر")} v={it.sub?.expiry ?? "—"} />
            <Kv k="ADI" v={it.sub?.adi ?? "—"} />
            <Kv k="CAS" v={it.sub?.cas ?? "—"} />
          </div>
          {it.alternatives.length > 0 && (
            <div className="mt-4">
              <div className="mb-2 text-xs font-bold text-leaf-700 dark:text-leaf-300">{tr("EU-compliant alternatives (same use, shortest PHI first)", "بدائل مطابقة أوروبيًا (نفس الاستخدام، الأقصر في فترة الأمان أولًا)")}</div>
              <div className="flex flex-wrap gap-2">
                {it.alternatives.map((a) => (
                  <span key={a.id} className="rounded-lg border border-leaf-200 bg-white px-2.5 py-1.5 text-xs dark:border-leaf-700/40 dark:bg-ink-900">
                    <b>{lang === "ar" ? a.ar : a.en}</b> <span className="text-ink-600/70 dark:text-sand-300/60" dir="ltr">({a.ai.map((x) => x.substance.split(" (")[0]).join(" + ")})</span> · PHI {num(a.phi)}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </Card>
  );
}

function Kv({ k, v }: { k: string; v: string }) {
  return (
    <div className="rounded-lg bg-white p-2 dark:bg-ink-900">
      <div className="text-[10px] text-ink-600/60 dark:text-sand-300/50">{k}</div>
      <div className="truncate font-semibold" dir="ltr" title={v}>{v}</div>
    </div>
  );
}
