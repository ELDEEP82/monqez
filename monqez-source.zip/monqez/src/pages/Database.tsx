import { useMemo, useState } from "react";
import { Search, Download } from "lucide-react";
import { useLang } from "../lang";
import { Card, SectionTitle, inputCls } from "../ui";
import { FUNCTION_CODES, MRLS, META, SUBSTANCES, TRADE, subById } from "../data";
import { RegClass, REG_LABEL, classify } from "../engine";

type Tab = "mrl" | "trade" | "subs";
const dotFor = (c: RegClass) => (["banned", "default", "noUseOnCrop", "unknown"].includes(c) ? "bg-bad" : c === "importTolerance" || c === "lowMrl" ? "bg-warn" : "bg-ok");

function mrlClass(m: (typeof MRLS)[number]): RegClass {
  const subs = m.subs.map((s) => subById.get(s)!).filter(Boolean);
  if (!subs.length) return m.loq || m.mrl == null ? "default" : "approved";
  const approved = subs.some((s) => s.status === "Approved");
  if (m.mrl == null) return approved ? "noUseOnCrop" : "default";
  if (m.loq) return approved ? "noUseOnCrop" : "banned";
  if (!approved) return "importTolerance";
  return m.mrl <= 0.05 ? "lowMrl" : "approved";
}

export default function Database() {
  const { tr, bi, lang, num } = useLang();
  const [tab, setTab] = useState<Tab>("mrl");
  const [q, setQ] = useState("");
  const [f, setF] = useState<"all" | "red" | "yellow" | "green">("all");
  const [page, setPage] = useState(1);
  const per = 40;

  const mrlRows = useMemo(() => MRLS.map((m) => ({ m, c: mrlClass(m) })), []);
  const rows = useMemo(() => {
    const s = q.trim().toLowerCase();
    const lv = (c: RegClass) => (dotFor(c) === "bg-bad" ? "red" : dotFor(c) === "bg-warn" ? "yellow" : "green");
    if (tab === "mrl") return mrlRows.filter(({ m, c }) => (!s || m.residue.toLowerCase().includes(s)) && (f === "all" || lv(c) === f));
    if (tab === "trade")
      return TRADE.filter((t) => !s || t.en.toLowerCase().includes(s) || t.ar.includes(q.trim()) || t.ai.some((a) => a.substance.toLowerCase().includes(s))).filter((t) => {
        if (f === "all") return true;
        const cs = t.ai.map((a) => classify(a.sid != null ? subById.get(a.sid) ?? null : null).regClass);
        const worst = cs.some((c) => lv(c) === "red") ? "red" : cs.some((c) => lv(c) === "yellow") ? "yellow" : "green";
        return worst === f;
      });
    return SUBSTANCES.filter((x) => (!s || x.name.toLowerCase().includes(s) || (x.cas ?? "").includes(s)) && (f === "all" || lv(classify(x).regClass) === f));
  }, [tab, q, f, mrlRows]);
  const pages = Math.max(1, Math.ceil(rows.length / per));
  const slice = rows.slice((page - 1) * per, page * per);

  const stats = useMemo(() => {
    const c = { red: 0, yellow: 0, green: 0 };
    mrlRows.forEach(({ c: k }) => (dotFor(k) === "bg-bad" ? c.red++ : dotFor(k) === "bg-warn" ? c.yellow++ : c.green++));
    return c;
  }, [mrlRows]);

  const exportCsv = () => {
    const lines = [["Pesticide residue", "MRL (mg/kg)", "LOQ", "Class", "Linked substances", "EU status"].join(",")];
    mrlRows.forEach(({ m, c }) => {
      const subs = m.subs.map((s) => subById.get(s)!);
      lines.push([`"${m.residue.replace(/"/g, "'")}"`, m.mrl ?? "", m.loq ? "yes" : "", REG_LABEL[c].en, `"${subs.map((s) => s.name).join("; ")}"`, `"${subs.map((s) => s.status).join("; ")}"`].join(","));
    });
    const blob = new Blob(["﻿" + lines.join("\n")], { type: "text/csv;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "monqez-oranges-eu-mrl.csv";
    a.click();
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <SectionTitle kicker={tr("Reference data", "البيانات المرجعية")} title={tr("EU pesticide database — oranges", "قاعدة بيانات المبيدات الأوروبية — البرتقال")} sub={`${META.mrlFile} · ${META.asFile}`} />

      <div className="mb-6 grid gap-3 sm:grid-cols-4">
        {[
          [num(META.counts.mrl), tr("MRL entries (oranges)", "حد أقصى (برتقال)"), "text-ink-900 dark:text-white"],
          [num(stats.red), tr("Zero-tolerance / banned", "صفر تسامح / محظور"), "text-bad"],
          [num(stats.yellow), tr("Import tolerance / very low MRL", "حد استيراد / حد منخفض جدًا"), "text-amber-600"],
          [num(stats.green), tr("Approved with workable MRL", "معتمد بحد عملي"), "text-ok"],
        ].map(([n, l, c], i) => (
          <Card key={i} className="p-4">
            <div className={`font-display text-3xl font-black ${c}`}>{n}</div>
            <div className="mt-1 text-xs font-semibold text-ink-700/70 dark:text-sand-200/60">{l}</div>
          </Card>
        ))}
      </div>

      <Card className="p-4 sm:p-5">
        <div className="mb-4 flex flex-wrap items-center gap-2">
          {([["mrl", tr("Orange MRLs", "حدود البرتقال")], ["trade", tr("Egyptian trade names", "الأسماء التجارية المصرية")], ["subs", tr("All active substances", "كل المواد الفعالة")]] as [Tab, string][]).map(([k, l]) => (
            <button key={k} onClick={() => { setTab(k); setPage(1); }} className={`rounded-lg px-3 py-2 text-sm font-semibold ${tab === k ? "bg-ink-900 text-white dark:bg-leaf-600" : "bg-sand-100 dark:bg-ink-800"}`}>{l}</button>
          ))}
          <div className="ms-auto flex flex-wrap items-center gap-2">
            {(["all", "red", "yellow", "green"] as const).map((k) => (
              <button key={k} onClick={() => { setF(k); setPage(1); }} className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold ring-1 ${f === k ? "bg-ink-900 text-white ring-ink-900 dark:bg-leaf-600" : "ring-sand-300 dark:ring-ink-600"}`}>
                {k !== "all" && <span className={`h-2 w-2 rounded-full ${k === "red" ? "bg-bad" : k === "yellow" ? "bg-warn" : "bg-ok"}`} />}
                {k === "all" ? tr("All", "الكل") : k === "red" ? tr("Red", "أحمر") : k === "yellow" ? tr("Yellow", "أصفر") : tr("Green", "أخضر")}
              </button>
            ))}
            {tab === "mrl" && <button onClick={exportCsv} className="flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold ring-1 ring-sand-300 dark:ring-ink-600"><Download className="h-3.5 w-3.5" />CSV</button>}
          </div>
        </div>
        <div className="relative mb-4">
          <Search className="pointer-events-none absolute top-1/2 h-4 w-4 -translate-y-1/2 text-ink-600/50 ltr:left-3 rtl:right-3" />
          <input value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} placeholder={tr("Search name or CAS…", "ابحث بالاسم أو رقم CAS…")} className={`${inputCls} ltr:pl-9 rtl:pr-9`} />
        </div>
        <div className="mb-2 text-xs text-ink-700/60 dark:text-sand-200/50">{num(rows.length)} {tr("results", "نتيجة")}</div>

        <div className="overflow-x-auto">
          {tab === "mrl" && (
            <table className="w-full min-w-[720px] text-sm">
              <thead><tr className="border-b border-sand-200 text-xs text-ink-600/70 dark:border-ink-700 dark:text-sand-300/60"><th className="p-2 text-start">{tr("Pesticide residue", "متبقي المبيد")}</th><th className="p-2 text-start">{tr("MRL (mg/kg)", "الحد (مجم/كجم)")}</th><th className="p-2 text-start">{tr("Classification", "التصنيف")}</th><th className="p-2 text-start">{tr("EU status of substance", "حالة المادة أوروبيًا")}</th></tr></thead>
              <tbody>
                {(slice as typeof mrlRows).map(({ m, c }) => {
                  const subs = m.subs.map((s) => subById.get(s)!);
                  return (
                    <tr key={m.pid + m.residue} className="border-b border-sand-100 dark:border-ink-800">
                      <td className="max-w-md p-2" dir="ltr"><span className="line-clamp-2">{m.residue}</span></td>
                      <td className="p-2 font-mono" dir="ltr">{m.raw ?? "—"}</td>
                      <td className="p-2"><span className="inline-flex items-center gap-1.5 text-xs"><span className={`h-2 w-2 rounded-full ${dotFor(c)}`} />{bi(REG_LABEL[c])}</span></td>
                      <td className="p-2 text-xs">{subs.length ? subs.map((s) => <div key={s.id}>{s.status}{s.status !== "Approved" && s.expiry ? ` · ${s.expiry}` : ""}</div>) : <span className="text-ink-600/50">{tr("not linked", "غير مربوط")}</span>}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
          {tab === "trade" && (
            <table className="w-full min-w-[720px] text-sm">
              <thead><tr className="border-b border-sand-200 text-xs text-ink-600/70 dark:border-ink-700 dark:text-sand-300/60"><th className="p-2 text-start">{tr("Trade name", "الاسم التجاري")}</th><th className="p-2 text-start">{tr("Active substance(s)", "المادة الفعالة")}</th><th className="p-2 text-start">{tr("Use", "الاستخدام")}</th><th className="p-2 text-start">PHI</th><th className="p-2 text-start">{tr("EU verdict on oranges", "الحكم الأوروبي على البرتقال")}</th></tr></thead>
              <tbody>
                {(slice as typeof TRADE).map((t) => (
                  <tr key={t.id} className="border-b border-sand-100 dark:border-ink-800">
                    <td className="p-2 font-semibold">{lang === "ar" ? t.ar : t.en} <span className="text-xs font-normal text-ink-600/60">{t.form !== "—" ? t.form : ""}</span></td>
                    <td className="p-2 text-xs" dir="ltr">{t.ai.map((a) => a.substance).join(" + ")}</td>
                    <td className="p-2 text-xs">{t.type}</td>
                    <td className="p-2 text-xs">{num(t.phi)} {tr("d", "يوم")}</td>
                    <td className="p-2 text-xs">{t.ai.map((a, i) => { const c = classify(a.sid != null ? subById.get(a.sid) ?? null : null); return <div key={i} className="flex items-center gap-1.5"><span className={`h-2 w-2 rounded-full ${dotFor(c.regClass)}`} />{bi(REG_LABEL[c.regClass])} <span className="font-mono" dir="ltr">{c.mrl?.raw ? `(${c.mrl.raw})` : ""}</span></div>; })}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          {tab === "subs" && (
            <table className="w-full min-w-[720px] text-sm">
              <thead><tr className="border-b border-sand-200 text-xs text-ink-600/70 dark:border-ink-700 dark:text-sand-300/60"><th className="p-2 text-start">{tr("Substance", "المادة")}</th><th className="p-2 text-start">CAS</th><th className="p-2 text-start">{tr("Status", "الحالة")}</th><th className="p-2 text-start">{tr("Approval / expiry", "الاعتماد / الانتهاء")}</th><th className="p-2 text-start">{tr("Function", "الوظيفة")}</th><th className="p-2 text-start">{tr("On oranges", "على البرتقال")}</th></tr></thead>
              <tbody>
                {(slice as typeof SUBSTANCES).map((s) => { const c = classify(s); return (
                  <tr key={s.id} className="border-b border-sand-100 dark:border-ink-800">
                    <td className="p-2" dir="ltr">{s.name}</td>
                    <td className="p-2 font-mono text-xs" dir="ltr">{s.cas}</td>
                    <td className="p-2 text-xs">{s.status}</td>
                    <td className="p-2 text-xs" dir="ltr">{s.approved ?? "—"} → {s.expiry ?? "—"}</td>
                    <td className="p-2 text-xs">{(s.functions ?? "").split(",").filter(Boolean).map((f) => (FUNCTION_CODES[f.trim()]?.[lang === "ar" ? 1 : 0] ?? f)).join("، ") || "—"}</td>
                    <td className="p-2 text-xs"><span className="inline-flex items-center gap-1.5"><span className={`h-2 w-2 rounded-full ${dotFor(c.regClass)}`} /><span className="font-mono" dir="ltr">{c.mrl?.raw ?? (c.regClass === "annexIV" ? "n/r" : "0.01")}</span></span></td>
                  </tr>
                ); })}
              </tbody>
            </table>
          )}
        </div>

        <div className="mt-4 flex items-center justify-center gap-2 text-sm">
          <button disabled={page <= 1} onClick={() => setPage(page - 1)} className="rounded-lg px-3 py-1.5 font-semibold ring-1 ring-sand-300 disabled:opacity-40 dark:ring-ink-600">{tr("Prev", "السابق")}</button>
          <span className="px-2 text-xs">{num(page)} / {num(pages)}</span>
          <button disabled={page >= pages} onClick={() => setPage(page + 1)} className="rounded-lg px-3 py-1.5 font-semibold ring-1 ring-sand-300 disabled:opacity-40 dark:ring-ink-600">{tr("Next", "التالي")}</button>
        </div>
      </Card>

      <Card className="mt-6 p-5 text-sm">
        <h3 className="mb-3 font-display font-bold">{tr("How to read EU MRL values", "إزاي تقرأ قيم الحدود الأوروبية")}</h3>
        <div className="grid gap-3 md:grid-cols-2">
          <div className="rounded-xl bg-sand-100 p-3 dark:bg-ink-800"><b className="font-mono">0.01*</b> — {tr("Asterisk = limit of analytical determination (LOQ). No actual residue is allowed; this is the lab's minimum detection limit.", "النجمة = حد التقدير المعملي (LOQ). لا يُسمح بأي متبقي فعلي؛ ده أقل حد يقدر المعمل يكشفه.")}</div>
          <div className="rounded-xl bg-sand-100 p-3 dark:bg-ink-800"><b className="font-mono">0.5</b> — {tr("No asterisk = a real Maximum Residue Level set for consumer safety.", "بدون نجمة = حد أقصى فعلي للمتبقيات محدد لسلامة المستهلك.")}</div>
          <div className="rounded-xl bg-sand-100 p-3 dark:bg-ink-800"><b>(F)</b> {tr("fat-soluble", "قابل للذوبان في الدهون")} · <b>(R)</b> {tr("residue definition differs for animal/plant products", "تعريف المتبقي يختلف بين المنتجات")} · <b>(A)</b> {tr("analytical standard issue noted by the EU", "ملاحظة أوروبية على المعيار التحليلي")}</div>
          <div className="rounded-xl bg-sand-100 p-3 dark:bg-ink-800">{tr("Annex IV substances need no MRL; substances not listed and not approved fall to the default 0.01 mg/kg (Art. 18(1)(b), Reg. 396/2005).", "مواد الملحق IV لا تحتاج حدًا؛ والمواد غير المدرجة وغير المعتمدة يطبق عليها الحد الافتراضي 0.01 مجم/كجم (المادة 18(1)(ب)، اللائحة 396/2005).")}</div>
        </div>
      </Card>
    </div>
  );
}
