import { useState } from "react";
import { ArrowLeft, ArrowRight, ShieldCheck, FlaskConical, Ship, ScanLine, Leaf, Package, FileText, Sparkles, Database as Db, CalendarClock } from "lucide-react";
import { useLang } from "../lang";
import { Btn, Card, LevelChip, Logo, ProductPicker } from "../ui";
import { go } from "../App";
import { META, subById, tradeById } from "../data";
import { Ref, classify, REG_LABEL, Level } from "../engine";

function QuickLookup() {
  const { tr, bi, lang } = useLang();
  const [ref, setRef] = useState<Ref>({ kind: "trade", id: [...tradeById.values()].find((t) => t.en === "Dursban")!.id });
  const subs = !ref ? [] : ref.kind === "trade" ? tradeById.get(ref.id)!.ai.map((a) => (a.sid != null ? subById.get(a.sid)! : null)) : [subById.get(ref.id)!];
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[.06] p-4 backdrop-blur sm:p-5">
      <div className="mb-3 flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-citrus-300">
        <Sparkles className="h-3.5 w-3.5" /> {tr("Try it: instant EU status for oranges", "جرّب: الحالة الأوروبية فورًا على البرتقال")}
      </div>
      <div className="text-ink-900">
        <ProductPicker value={ref} onChange={setRef} />
      </div>
      <div className="mt-3 space-y-2">
        {subs.map((s, i) => {
          if (!s) return null;
          const c = classify(s);
          const lv: Level = ["banned", "default", "noUseOnCrop", "unknown"].includes(c.regClass) ? "red" : c.regClass === "importTolerance" || c.regClass === "lowMrl" ? "yellow" : "green";
          return (
            <div key={i} className="rounded-xl bg-white/95 p-3 text-ink-900">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="font-semibold" dir="ltr">{s.name}</span>
                <LevelChip level={lv} />
              </div>
              <div className="mt-1.5 grid grid-cols-2 gap-2 text-xs text-ink-700">
                <div>
                  <span className="block text-[10px] uppercase text-ink-600/60">{tr("EU status", "الحالة في الاتحاد")}</span>
                  <b>{s.status === "Approved" ? tr("Approved", "معتمد") : s.status === "Pending" ? tr("Pending", "قيد المراجعة") : tr("Not approved", "غير معتمد")}</b>
                  {s.status !== "Approved" && s.expiry && <span className="text-ink-600/70"> · {tr("since", "منذ")} {s.expiry}</span>}
                </div>
                <div>
                  <span className="block text-[10px] uppercase text-ink-600/60">{tr("MRL on oranges", "الحد الأقصى على البرتقال")}</span>
                  <b dir="ltr">{c.mrl?.raw ? `${c.mrl.raw} mg/kg` : c.regClass === "annexIV" ? tr("Not required", "غير مطلوب") : "0.01 mg/kg (default)"}</b>
                </div>
              </div>
              <div className="mt-1.5 text-[11px] text-ink-600/80">{bi(REG_LABEL[c.regClass])}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default function Home() {
  const { tr, num, isAr } = useLang();
  const Arrow = isAr ? ArrowLeft : ArrowRight;
  return (
    <div>
      {/* HERO */}
      <section className="relative overflow-hidden bg-ink-950 text-white">
        <div className="grain absolute inset-0 opacity-60" />
        <div className="absolute -top-40 h-[520px] w-[520px] rounded-full bg-citrus-500/25 blur-3xl ltr:-right-32 rtl:-left-32" />
        <div className="absolute -bottom-48 h-[420px] w-[420px] rounded-full bg-leaf-500/20 blur-3xl ltr:-left-24 rtl:-right-24" />
        <div className="relative mx-auto grid max-w-7xl items-center gap-10 px-4 py-14 sm:px-6 lg:grid-cols-[1.15fr_.85fr] lg:py-20">
          <div className="fade-up">
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-3 py-1 text-xs font-semibold text-sand-100">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-citrus-400" />
              {tr("Prototype · Egyptian oranges → European Union", "نموذج أولي · البرتقال المصري ← الاتحاد الأوروبي")}
            </div>
            <h1 className="font-display text-4xl font-black leading-[1.15] sm:text-5xl lg:text-6xl">
              {tr("Know if your batch clears EU borders", "اعرف هل شحنتك هتعدّي حدود أوروبا")}
              <span className="block text-citrus-400">{tr("before you ship.", "قبل ما تشحنها.")}</span>
            </h1>
            <p className="mt-5 max-w-xl text-base leading-relaxed text-sand-200/85 sm:text-lg">
              {tr(
                "Monqez links the pesticide trade names used in Egypt to their active substances, EU approval status, Maximum Residue Levels and pre-harvest intervals — and flags rejection risk while there is still time to act.",
                "منقذ يربط الأسماء التجارية للمبيدات المستخدمة في مصر بموادها الفعالة وحالتها في الاتحاد الأوروبي والحدود القصوى للمتبقيات وفترات الأمان — وينبهك لخطر الرفض وأنت لسه قادر تتصرف."
              )}
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Btn onClick={() => go("check")} className="px-6 py-3 text-base">
                {tr("Check a batch now", "افحص شحنة الآن")} <Arrow className="h-4 w-4" />
              </Btn>
              <Btn variant="ghost" onClick={() => go("check", "demo=risky")} className="border border-white/20 px-6 py-3 text-base !text-white hover:!bg-white/10">
                {tr("See a risky demo batch", "شوف مثال لشحنة خطرة")}
              </Btn>
            </div>
            <div className="mt-10 grid max-w-xl grid-cols-3 gap-4 border-t border-white/10 pt-6">
              {[
                [num(623), tr("RASFF notifications on Egyptian food, 2019–2026", "إخطار RASFF على أغذية مصرية 2019–2026")],
                [num(76), tr("in the first half of 2026 alone", "في النصف الأول من 2026 وحده")],
                [num(META.counts.mrl), tr("EU MRL entries for oranges loaded", "حد أقصى أوروبي للبرتقال محمّل")],
              ].map(([n, l], i) => (
                <div key={i}>
                  <div className="font-display text-2xl font-black text-white sm:text-3xl">{n}</div>
                  <div className="mt-1 text-[11px] leading-snug text-sand-200/70 sm:text-xs">{l}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="fade-up" style={{ animationDelay: ".15s" }}>
            <QuickLookup />
          </div>
        </div>
      </section>

      {/* PROBLEM */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="grid gap-8 lg:grid-cols-2">
          <div>
            <div className="mb-2 text-xs font-bold uppercase tracking-[.18em] text-citrus-600">{tr("The problem", "المشكلة")}</div>
            <h2 className="font-display text-3xl font-extrabold leading-tight">{tr("Rejections are discovered at the border — when it's too late.", "الرفض بيتكشف على الحدود — بعد فوات الأوان.")}</h2>
            <p className="mt-4 leading-relaxed text-ink-700/85 dark:text-sand-200/75">
              {tr(
                "In June 2026 the Valencian Farmers Association (AVA-ASAJA) reported that the EU's RASFF system detected several banned pesticide residues in fruit and vegetables imported from Egypt during May 2026 — including chlorpropham, banned in the EU since 2019 but still not banned in Egypt.",
                "في يونيو 2026 أعلنت جمعية مزارعي فالنسيا (AVA-ASAJA) أن نظام الإنذار الأوروبي RASFF رصد متبقيات مبيدات محظورة في خضروات وفاكهة مستوردة من مصر خلال مايو 2026 — منها الكلوربروفام المحظور في الاتحاد الأوروبي منذ 2019 وغير المحظور في مصر حتى الآن."
              )}
            </p>
            <p className="mt-3 leading-relaxed text-ink-700/85 dark:text-sand-200/75">
              {tr(
                "The gap is informational: farmers know trade names, the EU regulates active substances. Monqez closes that gap before the shipment leaves.",
                "الفجوة معلوماتية: المزارع يعرف الأسماء التجارية، والاتحاد الأوروبي ينظّم المواد الفعالة. منقذ يسد الفجوة دي قبل ما الشحنة تتحرك."
              )}
            </p>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {[
              [Ship, tr("Container rejected or destroyed at EU port", "رفض الحاوية أو إعدامها في الميناء الأوروبي")],
              [FileText, tr("Increased border checks on all Egyptian citrus", "زيادة نسب الفحص على كل الموالح المصرية")],
              [FlaskConical, tr("Lab test only after shipping — no time to fix", "التحليل بعد الشحن — مفيش وقت للتصحيح")],
              [ShieldCheck, tr("Reputation damage for the exporter and the country", "ضرر لسمعة المصدّر وسمعة البلد")],
            ].map(([I, l], i) => {
              const Icon = I as typeof Ship;
              return (
                <Card key={i} className="p-5">
                  <Icon className="mb-3 h-6 w-6 text-citrus-500" />
                  <div className="text-sm font-semibold leading-snug">{l as string}</div>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="border-y border-sand-200 bg-white dark:border-ink-800 dark:bg-ink-900/50">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
          <div className="mb-10 text-center">
            <div className="mb-2 text-xs font-bold uppercase tracking-[.18em] text-citrus-600">{tr("How it works", "إزاي بيشتغل")}</div>
            <h2 className="font-display text-3xl font-extrabold">{tr("Three steps, one decision", "ثلاث خطوات، قرار واحد")}</h2>
          </div>
          <div className="grid gap-5 md:grid-cols-3">
            {[
              [tr("Enter the batch record", "أدخل سجل الشحنة"), tr("Spray program by trade name, plus post-harvest, storage and growth-regulator treatments — and the lab report if you have one.", "برنامج الرش بالأسماء التجارية، ومعها معاملات ما بعد الحصاد والتخزين ومنظمات النمو — وتقرير المعمل لو موجود.")],
              [tr("The engine cross-checks", "المحرك يراجع ويقارن"), tr("Each active substance is checked against EU approval status, the orange MRL, PHI vs. harvest date, and measured residue ÷ MRL.", "كل مادة فعالة تتقارن بحالتها في الاتحاد الأوروبي والحد الأقصى للبرتقال وفترة الأمان مقابل تاريخ الحصاد ونسبة المتبقي ÷ الحد.")],
              [tr("Act before shipping", "اتصرف قبل الشحن"), tr("Traffic-light verdict, clearance probability, a detailed report and EU-compliant alternatives for next season.", "نتيجة بنظام إشارة المرور، واحتمالية العبور، وتقرير تفصيلي، وبدائل مطابقة للموسم الجاي.")],
            ].map(([h, p], i) => (
              <div key={i} className="relative rounded-2xl border border-sand-200 bg-sand-50 p-6 dark:border-ink-700 dark:bg-ink-950">
                <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-xl bg-ink-900 font-display text-lg font-black text-citrus-400 dark:bg-leaf-700">{num(i + 1)}</div>
                <h3 className="font-display text-lg font-bold">{h}</h3>
                <p className="mt-2 text-sm leading-relaxed text-ink-700/80 dark:text-sand-200/70">{p}</p>
              </div>
            ))}
          </div>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3 text-sm">
            {(["green", "yellow", "red"] as Level[]).map((l) => (
              <LevelChip key={l} level={l} big />
            ))}
          </div>
        </div>
      </section>

      {/* MODULES */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
          <div>
            <div className="mb-2 text-xs font-bold uppercase tracking-[.18em] text-citrus-600">{tr("Platform", "المنصة")}</div>
            <h2 className="font-display text-3xl font-extrabold">{tr("More than an MRL checker", "أكتر من مجرد فاحص حدود")}</h2>
          </div>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[
            [ShieldCheck, tr("MRL & PHI compliance engine", "محرك مطابقة الحدود وفترات الأمان"), tr("Live", "يعمل"), "check", ""],
            [Db, tr("EU pesticide database for oranges", "قاعدة بيانات المبيدات الأوروبية للبرتقال"), tr("Live", "يعمل"), "database", ""],
            [ScanLine, tr("Pesticide label scanner (photo → active substance)", "ماسح عبوة المبيد (صورة ← المادة الفعالة)"), tr("Beta", "تجريبي"), "tools", "tab=scan"],
            [Package, tr("Container & packaging advisor", "مستشار الحاويات والتعبئة"), tr("Beta", "تجريبي"), "tools", "tab=pack"],
            [Leaf, tr("Shipment carbon footprint", "البصمة الكربونية للشحنة"), tr("Beta", "تجريبي"), "tools", "tab=carbon"],
            [CalendarClock, tr("Lab integration · more crops & destinations", "ربط المعامل · محاصيل ووجهات أكثر"), tr("Planned", "مخطط"), "method", ""],
          ].map(([I, h, b, r, q], i) => {
            const Icon = I as typeof Ship;
            return (
              <button key={i} onClick={() => go(r as never, (q as string) || undefined)} className="group text-start">
                <Card className="h-full p-5 transition group-hover:-translate-y-0.5 group-hover:border-citrus-300">
                  <div className="flex items-start justify-between">
                    <Icon className="h-7 w-7 text-leaf-600 dark:text-leaf-300" />
                    <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${b === tr("Live", "يعمل") ? "bg-leaf-100 text-leaf-700 dark:bg-leaf-700/30 dark:text-leaf-200" : b === tr("Beta", "تجريبي") ? "bg-citrus-100 text-citrus-700 dark:bg-citrus-700/30 dark:text-citrus-200" : "bg-sand-200 text-ink-700 dark:bg-ink-700 dark:text-sand-200"}`}>{b as string}</span>
                  </div>
                  <div className="mt-4 font-display font-bold">{h as string}</div>
                </Card>
              </button>
            );
          })}
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="relative overflow-hidden rounded-3xl bg-citrus-500 p-8 text-white sm:p-12">
          <div className="absolute -top-10 opacity-20 ltr:-right-10 rtl:-left-10"><Logo size={220} /></div>
          <h2 className="relative max-w-2xl font-display text-3xl font-black leading-tight sm:text-4xl">{tr("Cut your risk of rejection and loss.", "قلّل خطر الرفض والخسارة.")}</h2>
          <p className="relative mt-3 max-w-xl text-white/90">{tr("Monqez does not replace laboratory testing or official controls — it tells you, early, where to look.", "منقذ لا يغني عن التحليل المعملي أو الرقابة الرسمية — هو بيقولك بدري تبص فين.")}</p>
          <Btn variant="dark" onClick={() => go("check")} className="relative mt-6 px-6 py-3 text-base">
            {tr("Start a free batch check", "ابدأ فحص شحنة مجاني")} <Arrow className="h-4 w-4" />
          </Btn>
        </div>
      </section>
    </div>
  );
}
