import { useState } from "react";
import { Trash2, FolderOpen, Inbox } from "lucide-react";
import { EU_COUNTRIES, store, useLang } from "../lang";
import { Btn, Card, LevelChip, SectionTitle } from "../ui";
import { go } from "../App";
import type { Saved } from "./Check";

export default function History() {
  const { tr, lang, num } = useLang();
  const [items, setItems] = useState<Saved[]>(() => store.get<Saved[]>("mq-history", []));
  const del = (id: string) => {
    const n = items.filter((x) => x.batch.id !== id);
    setItems(n);
    store.set("mq-history", n);
  };
  const counts = { green: 0, yellow: 0, red: 0 };
  items.forEach((i) => counts[i.level]++);
  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6">
      <SectionTitle kicker={tr("Batch log", "سجل الشحنات")} title={tr("My batches", "شحناتي")} sub={tr("Saved checks are stored on this device only (prototype).", "الفحوصات المحفوظة متخزنة على الجهاز ده بس (نموذج أولي).")} />
      {items.length > 0 && (
        <div className="mb-6 grid grid-cols-3 gap-3">
          {(["red", "yellow", "green"] as const).map((l) => (
            <Card key={l} className="p-4 text-center">
              <div className={`font-display text-3xl font-black ${l === "red" ? "text-bad" : l === "yellow" ? "text-amber-600" : "text-ok"}`}>{num(counts[l])}</div>
              <div className="text-xs font-semibold text-ink-700/70 dark:text-sand-200/60">{l === "red" ? tr("High risk", "خطر مرتفع") : l === "yellow" ? tr("Borderline", "حدّي") : tr("Safe", "آمن")}</div>
            </Card>
          ))}
        </div>
      )}
      {items.length === 0 ? (
        <Card className="p-12 text-center">
          <Inbox className="mx-auto h-10 w-10 text-ink-600/40" />
          <p className="mt-3 text-sm text-ink-700/70 dark:text-sand-200/60">{tr("No saved batches yet.", "لا توجد شحنات محفوظة بعد.")}</p>
          <Btn className="mt-4" onClick={() => go("check")}>{tr("Check a batch", "افحص شحنة")}</Btn>
        </Card>
      ) : (
        <div className="space-y-3">
          {items.map((s) => {
            const c = EU_COUNTRIES.find((x) => x.code === s.batch.destination);
            return (
              <Card key={s.batch.id} className="flex flex-wrap items-center gap-4 p-4">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-display font-bold" dir="ltr">{s.batch.batchCode}</span>
                    <LevelChip level={s.level} />
                  </div>
                  <div className="mt-1 text-xs text-ink-700/70 dark:text-sand-200/60">
                    {s.batch.exporter || "—"} · {lang === "ar" ? c?.ar : c?.en} · {tr("harvest", "حصاد")} {s.batch.harvestDate} · {tr("saved", "حُفظ")} {new Date(s.savedAt).toLocaleDateString(lang === "ar" ? "ar-EG" : "en-GB")}
                  </div>
                </div>
                <div className="text-center">
                  <div className="font-display text-2xl font-black">{num(Math.round(s.pClear * 100))}%</div>
                  <div className="text-[10px] text-ink-600/60">{tr("clearance", "احتمال العبور")}</div>
                </div>
                <div className="flex gap-1">
                  <Btn variant="soft" onClick={() => go("check", `id=${s.batch.id}`)}><FolderOpen className="h-4 w-4" />{tr("Open", "فتح")}</Btn>
                  <button onClick={() => del(s.batch.id)} className="rounded-lg p-2.5 text-ink-600/60 hover:bg-red-50 hover:text-bad" aria-label="delete"><Trash2 className="h-4 w-4" /></button>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
