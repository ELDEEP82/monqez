import { useLang } from "../lang";
import { Card, SectionTitle } from "../ui";
import { META } from "../data";

export default function Method() {
  const { tr, num } = useLang();
  const P = (a: string, b: string) => <p className="mt-2 text-sm leading-relaxed text-ink-700/85 dark:text-sand-200/75">{tr(a, b)}</p>;
  const rows: [string, string, string, string][] = [
    [tr("Banned / zero tolerance (MRL at LOQ*)", "محظور / صفر تسامح (الحد عند حد الكشف*)"), "Δt < PHI", "0.95", "🔴"],
    ["", "PHI ≤ Δt < 2·PHI", "0.75", "🔴"],
    ["", "2·PHI ≤ Δt < 4·PHI", "0.50", "🔴"],
    ["", "Δt ≥ 4·PHI", "0.30", "🔴"],
    [tr("EU-approved, MRL set", "معتمد، له حد"), "Δt < PHI", "0.65", "🔴"],
    ["", "PHI ≤ Δt < margin", "0.18", "🟡"],
    ["", "Δt ≥ margin", "0.03", "🟢"],
    [tr("Import tolerance / very low MRL", "حد استيراد / حد منخفض جدًا"), "Δt < PHI", "0.65–0.75", "🔴"],
    ["", "PHI ≤ Δt < margin (×1.5)", "0.25–0.28", "🟡"],
    ["", "Δt ≥ margin", "0.05–0.08", "🟢"],
    [tr("Post-harvest / storage use", "استخدام بعد الحصاد / التخزين"), tr("no decline", "بدون تكسير"), "0.15–0.95", "🟡/🔴"],
    [tr("Lab result: residue ÷ MRL", "نتيجة المعمل: المتبقي ÷ الحد"), "> 2 · > 1 · > 0.7 · > 0.3 · ≤ 0.3", "0.98 · 0.90 · 0.35 · 0.10 · 0.03", "🔴🔴🟡🟢🟢"],
  ];
  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6">
      <SectionTitle kicker={tr("How Monqez decides", "إزاي منقذ بيقرر")} title={tr("Methodology & limitations", "المنهجية والقيود")} />

      <Card className="p-6">
        <h3 className="font-display text-lg font-bold">{tr("1 · Risk function", "١ · دالة الخطر")}</h3>
        <div className="mt-3 overflow-x-auto rounded-xl bg-ink-950 p-4 font-mono text-sm text-citrus-200" dir="ltr">
          Risk_i = f(Crop, Active_Substance, Δt = Harvest − Spray, PHI, EU_MRL, EU_status, Lab_residue)
          <br />
          P(reject batch) = 1 − Π<sub>i</sub> (1 − p<sub>i</sub>)
          <br />
          P(clear) = Π<sub>i</sub> (1 − p<sub>i</sub>) &nbsp;&nbsp;·&nbsp;&nbsp; margin = max(1.3·PHI, PHI + 7 d)
        </div>
        {P(
          "Each active substance i in the batch gets a probability p_i of causing a border non-compliance. Assuming violations are independent, the batch clears only if no substance violates — so the clearance probability is the product of (1 − p_i). One red substance is enough to sink a batch, which matches how RASFF works.",
          "كل مادة فعالة i في الشحنة بتاخد احتمال p_i إنها تسبب مخالفة على الحدود. بافتراض استقلال المخالفات، الشحنة تعدّي فقط لو مفيش ولا مادة مخالفة — فاحتمال العبور = حاصل ضرب (1 − p_i). مادة حمراء واحدة كفاية توقع الشحنة، وده بيطابق طريقة عمل RASFF."
        )}
        <div className="mt-4 overflow-x-auto">
          <table className="w-full min-w-[560px] text-sm">
            <thead><tr className="border-b border-sand-200 text-xs text-ink-600/70 dark:border-ink-700"><th className="p-2 text-start">{tr("Regulatory class", "التصنيف التنظيمي")}</th><th className="p-2 text-start">{tr("Condition", "الشرط")}</th><th className="p-2 text-start">p_i</th><th className="p-2 text-start">{tr("Level", "المستوى")}</th></tr></thead>
            <tbody>{rows.map((r, i) => <tr key={i} className="border-b border-sand-100 dark:border-ink-800"><td className="p-2 font-semibold">{r[0]}</td><td className="p-2 font-mono text-xs" dir="ltr">{r[1]}</td><td className="p-2 font-mono text-xs" dir="ltr">{r[2]}</td><td className="p-2">{r[3]}</td></tr>)}</tbody>
          </table>
        </div>
        {P(
          "Thresholds: p ≥ 0.50 → red, 0.15 ≤ p < 0.50 → yellow, p < 0.15 → green. Zero-tolerance substances are always red. The 1.3·PHI margin and 50% lab-uncertainty step (EU SANTE guidance applies a default ±50% expanded measurement uncertainty at enforcement) are prototype parameters.",
          "الحدود: p ≥ 0.50 ← أحمر، 0.15 ≤ p < 0.50 ← أصفر، p < 0.15 ← أخضر. مواد صفر التسامح دائمًا حمراء. هامش 1.3×فترة الأمان وخطوة عدم اليقين المعملي 50% (إرشادات SANTE الأوروبية تطبق هامش عدم يقين افتراضي ±50% عند الرقابة) هي معاملات النموذج الأولي."
        )}
        <div className="mt-4 rounded-xl border border-citrus-200 bg-citrus-50 p-4 text-sm text-citrus-900 dark:border-citrus-700/40 dark:bg-citrus-700/10 dark:text-citrus-100">
          <b>{tr("Is there a formula for prediction accuracy?", "هل فيه معادلة لتحديد نسبة التنبؤ؟")}</b>
          {P(
            "Yes — in two stages. Now: the transparent rule-based score above (explainable to exporters and judges). Next: calibrate p_i with logistic regression on historical RASFF notifications for Egyptian citrus plus exporter lab results — logit(p) = β0 + β1·(Δt/PHI) + β2·log(MRL) + β3·banned + β4·postharvest + β5·RASFF_frequency — and measure accuracy with AUC/ROC, precision/recall for rejected batches, and the Brier score on held-out shipments.",
            "أيوه — على مرحلتين. دلوقتي: الدرجة القائمة على قواعد واضحة اللي فوق (سهل تشرحها للمصدّر وللجنة التحكيم). المرحلة الجاية: معايرة p_i بالانحدار اللوجستي على بيانات إخطارات RASFF التاريخية للموالح المصرية ونتائج معامل المصدّرين — logit(p) = β0 + β1·(Δt/PHI) + β2·log(MRL) + β3·محظور + β4·بعد الحصاد + β5·تكرار RASFF — وقياس الدقة بـAUC/ROC والدقة/الاستدعاء للشحنات المرفوضة ومقياس Brier على شحنات اختبار."
          )}
        </div>
      </Card>

      <Card className="mt-6 p-6">
        <h3 className="font-display text-lg font-bold">{tr("2 · Data pipeline", "٢ · مسار البيانات")}</h3>
        <div className="mt-4 grid gap-3 sm:grid-cols-4">
          {[
            [tr("EU Pesticides DB", "قاعدة بيانات المبيدات الأوروبية"), `${num(META.counts.mrl)} ${tr("orange MRLs", "حد للبرتقال")} · ${num(META.counts.substances)} ${tr("substances", "مادة")}`],
            [tr("Egyptian APC registry", "سجل لجنة المبيدات المصرية"), tr(`trade name → active substance (${META.counts.tradeNames} demo entries)`, `اسم تجاري ← مادة فعالة (${META.counts.tradeNames} عينة)`)],
            [tr("RASFF Window", "نافذة RASFF"), tr("historical rejections (calibration, next phase)", "حالات الرفض التاريخية (للمعايرة، المرحلة الجاية)")],
            [tr("Exporter inputs", "مدخلات المصدّر"), tr("spray log, post-harvest use, lab report", "سجل الرش، مواد ما بعد الحصاد، تقرير المعمل")],
          ].map(([h, s], i) => (
            <div key={i} className="rounded-xl bg-sand-100 p-3 dark:bg-ink-800"><div className="text-sm font-bold">{h}</div><div className="mt-1 text-xs text-ink-700/70 dark:text-sand-200/60">{s}</div></div>
          ))}
        </div>
        {P(
          "Matching: each MRL residue definition is linked to its active substance(s) — including group definitions such as dithiocarbamates (mancozeb, maneb…), carbendazim + benomyl, or total copper.",
          "الربط: كل تعريف متبقي في جدول الحدود مربوط بالمادة/المواد الفعالة — بما فيها التعريفات المجمعة زي الداي ثيوكاربامات (مانكوزيب، مانب…)، والكاربندازيم + البينوميل، والنحاس الكلي."
        )}
      </Card>

      <Card className="mt-6 p-6">
        <h3 className="font-display text-lg font-bold">{tr("3 · Limitations", "٣ · القيود")}</h3>
        <ul className="mt-3 list-disc space-y-2 ps-5 text-sm leading-relaxed text-ink-700/85 dark:text-sand-200/75">
          <li>{tr("Compliance, not toxicology: EFSA risk assessment (e.g. RACE) compares exposure with ADI/ARfD. An MRL exceedance does not automatically imply a health risk.", "مطابقة وليس سمية: تقييم EFSA (مثل RACE) يقارن التعرض بـADI/ARfD. تخطي الحد لا يعني تلقائيًا خطرًا صحيًا.")}</li>
          <li>{tr("The exceedance ratio (residue ÷ MRL) is a simplified indicator devised for this tool, not an official EFSA/RASFF metric.", "نسبة التخطي (المتبقي ÷ الحد) مؤشر مبسط خاص بالأداة، وليست مقياسًا رسميًا.")}</li>
          <li>{tr("Cross-contamination in shared storage/transport cannot be predicted from spray records; it is flagged when the lab detects undeclared substances.", "التلوث العرضي في التخزين/النقل المشترك لا يمكن توقعه من سجلات الرش؛ ويتم التنبيه عليه لما المعمل يكتشف مواد غير مسجلة.")}</li>
          <li>{tr("Not all substances in the database are field insecticides — growth regulators, post-harvest fungicides and storage treatments behave differently; Monqez models post-harvest use separately (no residue decline).", "مش كل المواد في القاعدة مبيدات حقلية — منظمات النمو ومبيدات ما بعد الحصاد ومعاملات التخزين سلوكها مختلف؛ منقذ بيحسب استخدام ما بعد الحصاد بشكل منفصل (بدون تكسير للمتبقي).")}</li>
          <li>{tr("EU rules only (harmonised across all 27 member states). USA, UK and Gulf markets have different limits.", "قواعد الاتحاد الأوروبي فقط (موحدة على كل الدول الأعضاء الـ27). أسواق أمريكا وبريطانيا والخليج لها حدود مختلفة.")}</li>
          <li>{tr("PHI values and the trade-name list in this prototype are indicative demo data, to be replaced by the official APC registry and product labels.", "فترات الأمان وقائمة الأسماء التجارية في النموذج الأولي بيانات توضيحية، هيتم استبدالها بسجل لجنة المبيدات الرسمي وعبوات المنتجات.")}</li>
        </ul>
      </Card>

      <div className="mt-6 grid gap-6 md:grid-cols-2">
        <Card className="p-6">
          <h3 className="font-display text-lg font-bold">{tr("4 · Architecture", "٤ · البنية التقنية")}</h3>
          <div className="mt-3 space-y-2 text-sm">
            {[
              [tr("Prototype (this app)", "النموذج الأولي (التطبيق ده)"), tr("React + Tailwind, risk engine in TypeScript running in the browser, EU data compiled to JSON, deployed on Vercel.", "React + Tailwind، محرك الخطر بـTypeScript يعمل في المتصفح، بيانات الاتحاد الأوروبي محولة لـJSON، منشور على Vercel.")],
              [tr("Production", "النسخة النهائية"), tr("Next.js PWA (packhouse desktop + in-field mobile) · FastAPI microservices for regulatory parsing and risk modelling · PostgreSQL (Supabase) for substance maps, MRL matrices and batch logs.", "Next.js PWA (لمحطة التعبئة والموبايل في الحقل) · خدمات FastAPI لتحليل التشريعات ونمذجة الخطر · PostgreSQL (Supabase) لخرائط المواد ومصفوفات الحدود وسجلات الشحنات.")],
            ].map(([h, s], i) => <div key={i} className="rounded-xl bg-sand-100 p-3 dark:bg-ink-800"><b>{h}</b><div className="mt-1 text-ink-700/80 dark:text-sand-200/70">{s}</div></div>)}
          </div>
        </Card>
        <Card className="p-6">
          <h3 className="font-display text-lg font-bold">{tr("5 · Business model", "٥ · نموذج العمل")}</h3>
          <div className="mt-3 space-y-2 text-sm">
            {[
              [tr("Freemium", "مجاني"), tr("3 free batch checks — verdict only.", "3 فحوصات مجانية — النتيجة فقط.")],
              [tr("Pay-per-check", "دفع لكل فحص"), tr("Detailed report: what went wrong, since when the substance is banned, by how much the limit is exceeded.", "تقرير تفصيلي: إيه المشكلة، المادة محظورة من امتى، وتخطت الحد بكام.")],
              [tr("Subscription", "اشتراك شهري"), tr("Unlimited history and reports — after validating freemium.", "سجل وتقارير بلا حدود — بعد اختبار النموذج المجاني.")],
            ].map(([h, s], i) => <div key={i} className="flex gap-3 rounded-xl bg-sand-100 p-3 dark:bg-ink-800"><b className="w-28 shrink-0">{h}</b><span className="text-ink-700/80 dark:text-sand-200/70">{s}</span></div>)}
          </div>
        </Card>
      </div>

      <Card className="mt-6 p-6">
        <h3 className="font-display text-lg font-bold">{tr("6 · Roadmap — 12 weeks", "٦ · الخطة الزمنية — 12 أسبوع")}</h3>
        <div className="mt-4 grid gap-2 sm:grid-cols-5">
          {[
            [tr("Research & data", "البحث والبيانات"), 3, false],
            [tr("Data structuring & model", "هيكلة البيانات والنموذج"), 3, false],
            [tr("Build MVP", "بناء المنتج"), 3, false],
            [tr("Testing & validation", "الاختبار والتحقق"), 2, false],
            [tr("Presentation", "العرض"), 1, false],
          ].map(([h, w, d], i) => (
            <div key={i} className={`rounded-xl p-3 ${d ? "bg-leaf-600 text-white" : "bg-sand-100 dark:bg-ink-800"}`} style={{ gridColumn: "span 1" }}>
              <div className="text-xs font-bold opacity-80">{num(w as number)} {tr("wks", "أسابيع")}</div>
              <div className="text-sm font-semibold">{h as string}</div>
            </div>
          ))}
        </div>
        {P("Next: more crops (grapes, strawberries, potatoes), more destinations (UK, GCC, USA), lab-report upload, image recognition of Egyptian pesticide packaging, carbon reporting.", "بعد كده: محاصيل أكتر (عنب، فراولة، بطاطس)، وجهات أكتر (بريطانيا، الخليج، أمريكا)، رفع تقارير المعامل، التعرف بالصور على عبوات المبيدات المصرية، تقارير الكربون.")}
      </Card>
    </div>
  );
}
