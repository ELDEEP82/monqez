import { createContext, useContext } from "react";

export type Lang = "ar" | "en";
export const LangCtx = createContext<{ lang: Lang; setLang: (l: Lang) => void }>({ lang: "ar", setLang: () => {} });

export function useLang() {
  const { lang, setLang } = useContext(LangCtx);
  const tr = (en: string, ar: string) => (lang === "ar" ? ar : en);
  const bi = (b: { en: string; ar: string }) => (lang === "ar" ? b.ar : b.en);
  const num = (n: number, d = 0) => n.toLocaleString(lang === "ar" ? "ar-EG" : "en-US", { maximumFractionDigits: d, minimumFractionDigits: d });
  return { lang, setLang, tr, bi, num, isAr: lang === "ar" };
}

export const store = {
  get<T>(k: string, fallback: T): T {
    try {
      const v = localStorage.getItem(k);
      return v ? (JSON.parse(v) as T) : fallback;
    } catch {
      return fallback;
    }
  },
  set(k: string, v: unknown) {
    try {
      localStorage.setItem(k, JSON.stringify(v));
    } catch {
      /* storage unavailable */
    }
  },
};

export const EU_COUNTRIES: { code: string; en: string; ar: string }[] = [
  ["AT", "Austria", "النمسا"], ["BE", "Belgium", "بلجيكا"], ["BG", "Bulgaria", "بلغاريا"], ["HR", "Croatia", "كرواتيا"], ["CY", "Cyprus", "قبرص"],
  ["CZ", "Czechia", "التشيك"], ["DK", "Denmark", "الدنمارك"], ["EE", "Estonia", "إستونيا"], ["FI", "Finland", "فنلندا"], ["FR", "France", "فرنسا"],
  ["DE", "Germany", "ألمانيا"], ["GR", "Greece", "اليونان"], ["HU", "Hungary", "المجر"], ["IE", "Ireland", "أيرلندا"], ["IT", "Italy", "إيطاليا"],
  ["LV", "Latvia", "لاتفيا"], ["LT", "Lithuania", "ليتوانيا"], ["LU", "Luxembourg", "لوكسمبورج"], ["MT", "Malta", "مالطا"], ["NL", "Netherlands", "هولندا"],
  ["PL", "Poland", "بولندا"], ["PT", "Portugal", "البرتغال"], ["RO", "Romania", "رومانيا"], ["SK", "Slovakia", "سلوفاكيا"], ["SI", "Slovenia", "سلوفينيا"],
  ["ES", "Spain", "إسبانيا"], ["SE", "Sweden", "السويد"],
].map(([code, en, ar]) => ({ code, en, ar }));
