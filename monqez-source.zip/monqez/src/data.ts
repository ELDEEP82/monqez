import raw from "./data/monqez.json";

export type Substance = {
  id: number;
  name: string;
  cas: string | null;
  status: "Approved" | "Not approved" | "Pending" | string | null;
  approved: string | null;
  expiry: string | null;
  legislation: string | null;
  cfs: string | null;
  lowRisk: string | null;
  basic: string | null;
  adi: string | null;
  arfd: string | null;
  functions: string | null;
  classification: string | null;
};

export type Mrl = {
  pid: number;
  residue: string;
  mrl: number | null;
  loq: boolean;
  raw: string | null;
  flags: string[];
  subs: number[];
};

export type TradeAI = { substance: string; sid: number | null; residuePid: number | null };
export type Trade = {
  id: string;
  en: string;
  ar: string;
  form: string;
  type: string;
  phi: number;
  rate: string;
  ai: TradeAI[];
};

const data = raw as unknown as {
  meta: { mrlFile: string; asFile: string; product: string; counts: { mrl: number; substances: number; tradeNames: number } };
  substances: Substance[];
  mrls: Mrl[];
  trade: Trade[];
};

export const META = data.meta;
export const SUBSTANCES = data.substances;
export const MRLS = data.mrls;
export const TRADE = data.trade;

export const subById = new Map<number, Substance>(SUBSTANCES.map((s) => [s.id, s]));
export const mrlByPid = new Map<number, Mrl>(MRLS.map((m) => [m.pid, m]));
export const mrlBySub = new Map<number, Mrl>();
for (const m of MRLS) for (const s of m.subs) if (!mrlBySub.has(s)) mrlBySub.set(s, m);
export const tradeById = new Map<string, Trade>(TRADE.map((t) => [t.id, t]));

/** Parse EU dd/mm/yyyy date */
export function parseEuDate(s: string | null): Date | null {
  if (!s) return null;
  const m = s.match(/(\d{2})\/(\d{2})\/(\d{4})/);
  if (!m) return null;
  return new Date(Date.UTC(+m[3], +m[2] - 1, +m[1]));
}

export const FUNCTION_CODES: Record<string, [string, string]> = {
  AC: ["Acaricide", "مبيد أكاروسي"],
  IN: ["Insecticide", "مبيد حشري"],
  FU: ["Fungicide", "مبيد فطري"],
  HB: ["Herbicide", "مبيد حشائش"],
  PG: ["Plant growth regulator", "منظم نمو"],
  NE: ["Nematicide", "مبيد نيماتودا"],
  BA: ["Bactericide", "مبيد بكتيري"],
  RE: ["Repellent", "طارد"],
  RO: ["Rodenticide", "مبيد قوارض"],
  MO: ["Molluscicide", "مبيد رخويات"],
  AT: ["Attractant", "جاذب"],
  EL: ["Elicitor", "محفز مناعة"],
  SO: ["Soil sterilant", "معقم تربة"],
  PA: ["Plant activator", "منشط نبات"],
  ST: ["Seed treatment", "معاملة بذور"],
  TH: ["Thinner", "مخفف ثمار"],
  OT: ["Other", "أخرى"],
  "OT-PO": ["Other", "أخرى"],
  VI: ["Virucide", "مبيد فيروسي"],
};
