import { useEffect, useState } from "react";
import { Moon, Sun, Languages, Menu, X } from "lucide-react";
import { Lang, LangCtx, store, useLang } from "./lang";
import { Logo } from "./ui";
import Home from "./pages/Home";
import Check from "./pages/Check";
import Database from "./pages/Database";
import Tools from "./pages/Tools";
import History from "./pages/History";
import Method from "./pages/Method";

export type Route = "home" | "check" | "database" | "tools" | "history" | "method";
const ROUTES: Route[] = ["home", "check", "database", "tools", "history", "method"];

function readRoute(): Route {
  const h = (location.hash || "").replace(/^#\/?/, "").split("?")[0] as Route;
  return ROUTES.includes(h) ? h : "home";
}

export function go(r: Route, q?: string) {
  location.hash = `/${r}${q ? `?${q}` : ""}`;
  window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
}

function Shell() {
  const { tr, lang, setLang } = useLang();
  const [route, setRoute] = useState<Route>(readRoute());
  const [dark, setDark] = useState<boolean>(() => {
    const saved = store.get<boolean | null>("mq-dark", null);
    if (saved !== null) return saved;
    const attr = document.documentElement.getAttribute("data-theme");
    if (attr) return attr === "dark";
    try { return window.matchMedia("(prefers-color-scheme: dark)").matches; } catch { return false; }
  });
  const [menu, setMenu] = useState(false);
  useEffect(() => {
    const h = () => { setRoute(readRoute()); setMenu(false); };
    window.addEventListener("hashchange", h);
    return () => window.removeEventListener("hashchange", h);
  }, []);
  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
    document.documentElement.style.colorScheme = dark ? "dark" : "light";
  }, [dark]);

  const nav: [Route, string][] = [
    ["home", tr("Home", "الرئيسية")],
    ["check", tr("Batch check", "فحص شحنة")],
    ["database", tr("EU database", "قاعدة البيانات")],
    ["tools", tr("Export tools", "أدوات التصدير")],
    ["history", tr("My batches", "شحناتي")],
    ["method", tr("Methodology", "المنهجية")],
  ];

  return (
    <div className="min-h-screen bg-sand-50 text-ink-900 dark:bg-ink-950 dark:text-sand-50">
      <header className="no-print sticky top-0 z-40 border-b border-sand-200/80 bg-sand-50/85 backdrop-blur-md dark:border-ink-800 dark:bg-ink-950/85">
        <div className="mx-auto flex h-16 max-w-7xl items-center gap-4 px-4 sm:px-6">
          <a href="#/home" className="flex items-center gap-2.5">
            <Logo size={34} />
            <span className="leading-none">
              <span className="block font-display text-lg font-extrabold tracking-tight">{tr("Monqez", "منقذ")}</span>
              <span className="block text-[10px] font-semibold tracking-wider text-ink-600/70 dark:text-sand-300/60">{tr("منقذ · EU MRL pre-screening", "Monqez · فحص مسبق للشحنات")}</span>
            </span>
          </a>
          <nav className="mx-auto hidden items-center gap-1 lg:flex">
            {nav.map(([r, l]) => (
              <a key={r} href={`#/${r}`} className={`rounded-lg px-3 py-2 text-sm font-semibold transition ${route === r ? "bg-ink-900 text-white dark:bg-leaf-600" : "text-ink-700 hover:bg-sand-100 dark:text-sand-200 dark:hover:bg-ink-800"}`}>
                {l}
              </a>
            ))}
          </nav>
          <div className="ms-auto flex items-center gap-1 lg:ms-0">
            <button onClick={() => setLang(lang === "ar" ? "en" : "ar")} className="flex items-center gap-1.5 rounded-lg px-2.5 py-2 text-sm font-bold hover:bg-sand-100 dark:hover:bg-ink-800" aria-label="language">
              <Languages className="h-4 w-4" />
              {lang === "ar" ? "EN" : "عربي"}
            </button>
            <button onClick={() => { setDark(!dark); store.set("mq-dark", !dark); }} className="rounded-lg p-2 hover:bg-sand-100 dark:hover:bg-ink-800" aria-label="theme">
              {dark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </button>
            <button onClick={() => setMenu(!menu)} className="rounded-lg p-2 hover:bg-sand-100 lg:hidden dark:hover:bg-ink-800" aria-label="menu">
              {menu ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
        {menu && (
          <nav className="grid gap-1 border-t border-sand-200 px-4 py-3 lg:hidden dark:border-ink-800">
            {nav.map(([r, l]) => (
              <a key={r} href={`#/${r}`} className={`rounded-lg px-3 py-2.5 text-sm font-semibold ${route === r ? "bg-ink-900 text-white dark:bg-leaf-600" : ""}`}>
                {l}
              </a>
            ))}
          </nav>
        )}
      </header>

      <main>
        {route === "home" && <Home />}
        {route === "check" && <Check />}
        {route === "database" && <Database />}
        {route === "tools" && <Tools />}
        {route === "history" && <History />}
        {route === "method" && <Method />}
      </main>

      <footer className="no-print mt-20 border-t border-sand-200 bg-white/60 dark:border-ink-800 dark:bg-ink-900/40">
        <div className="mx-auto grid max-w-7xl gap-6 px-4 py-10 text-sm sm:px-6 md:grid-cols-3">
          <div>
            <div className="mb-2 flex items-center gap-2 font-display text-lg font-extrabold"><Logo size={26} />{tr("Monqez", "منقذ")}</div>
            <p className="text-ink-700/80 dark:text-sand-200/70">{tr("A pre-screening and decision-support tool. It does not replace laboratory testing or official border controls.", "أداة فحص مسبق ودعم قرار. لا تغني عن التحليل المعملي أو الرقابة الرسمية على الحدود.")}</p>
          </div>
          <div className="text-ink-700/80 dark:text-sand-200/70">
            <div className="mb-2 font-bold text-ink-900 dark:text-white">{tr("Data sources", "مصادر البيانات")}</div>
            <p>EU Pesticides Database — MRLs (0110020 Oranges, 19/09/2026) · Active substances (20/09/2026)</p>
            <p className="mt-1">{tr("Trade-name map: demo sample — to be replaced by the Egyptian APC registry.", "ربط الأسماء التجارية: عينة توضيحية — سيتم استبدالها بسجل لجنة المبيدات الزراعية المصرية.")}</p>
          </div>
          <div className="text-ink-700/80 dark:text-sand-200/70">
            <div className="mb-2 font-bold text-ink-900 dark:text-white">{tr("Project", "المشروع")}</div>
            <p>{tr("Idea & research: Howida R. Al-Refae", "الفكرة والبحث: هويدا ر. الرفاعي")}</p>
            <p className="mt-1">{tr("Prototype v0.1 · MVP scope: Egyptian oranges → EU", "نموذج أولي v0.1 · نطاق المنتج: البرتقال المصري ← الاتحاد الأوروبي")}</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default function App() {
  const [lang, setLangState] = useState<Lang>(() => store.get<Lang>("mq-lang", "ar"));
  const setLang = (l: Lang) => {
    setLangState(l);
    store.set("mq-lang", l);
  };
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  }, [lang]);
  return (
    <LangCtx.Provider value={{ lang, setLang }}>
      <Shell />
    </LangCtx.Provider>
  );
}
