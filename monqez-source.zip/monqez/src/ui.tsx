import { ReactNode, useEffect, useMemo, useRef, useState } from "react";
import { Search, X } from "lucide-react";
import { SUBSTANCES, TRADE, subById, tradeById } from "./data";
import { Level, Ref, classify, REG_LABEL } from "./engine";
import { useLang } from "./lang";

export function Logo({ size = 36 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" aria-hidden>
      <circle cx="32" cy="35" r="25" fill="#ef7410" />
      <circle cx="32" cy="35" r="25" fill="url(#lg)" opacity=".35" />
      <circle cx="32" cy="35" r="10.5" fill="#fff6ec" />
      <path d="M32 10v14.5M32 45.5V60M7 35h14.5M42.5 35H57" stroke="#fff6ec" strokeWidth="5" strokeLinecap="round" />
      <path d="M33 10.5c3.5-6.5 11.5-8 16.5-5-4 5.5-10.5 7.5-16.5 5z" fill="#2f8556" />
      <defs>
        <radialGradient id="lg" cx=".3" cy=".25" r=".8">
          <stop offset="0" stopColor="#fff" />
          <stop offset="1" stopColor="#fff" stopOpacity="0" />
        </radialGradient>
      </defs>
    </svg>
  );
}

export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`rounded-2xl border border-sand-200 bg-white shadow-card dark:border-ink-700 dark:bg-ink-900 ${className}`}>{children}</div>;
}

export const LEVEL_STYLE: Record<Level, { dot: string; chip: string; ring: string; text: string }> = {
  green: { dot: "bg-ok", chip: "bg-emerald-50 text-emerald-800 ring-emerald-200 dark:bg-emerald-950/50 dark:text-emerald-300 dark:ring-emerald-800", ring: "ring-ok", text: "text-ok" },
  yellow: { dot: "bg-warn", chip: "bg-amber-50 text-amber-800 ring-amber-200 dark:bg-amber-950/50 dark:text-amber-300 dark:ring-amber-800", ring: "ring-warn", text: "text-amber-600 dark:text-amber-400" },
  red: { dot: "bg-bad", chip: "bg-red-50 text-red-800 ring-red-200 dark:bg-red-950/50 dark:text-red-300 dark:ring-red-800", ring: "ring-bad", text: "text-bad" },
};

export function LevelChip({ level, big = false }: { level: Level; big?: boolean }) {
  const { tr } = useLang();
  const label = level === "green" ? tr("Safe · compliant", "آمن · مطابق") : level === "yellow" ? tr("Caution · borderline", "تحذير · حدّي") : tr("High rejection risk", "خطر رفض مرتفع");
  return (
    <span className={`inline-flex items-center gap-2 rounded-full font-semibold ring-1 ${LEVEL_STYLE[level].chip} ${big ? "px-4 py-1.5 text-sm" : "px-2.5 py-0.5 text-xs"}`}>
      <span className={`h-2 w-2 rounded-full ${LEVEL_STYLE[level].dot}`} />
      {label}
    </span>
  );
}

export function Btn({ children, onClick, variant = "primary", className = "", type = "button", disabled }: { children: ReactNode; onClick?: () => void; variant?: "primary" | "ghost" | "soft" | "dark"; className?: string; type?: "button" | "submit"; disabled?: boolean }) {
  const v = {
    primary: "bg-citrus-500 text-white hover:bg-citrus-600 shadow-[0_6px_20px_-8px_rgba(239,116,16,.7)]",
    dark: "bg-ink-900 text-white hover:bg-ink-800 dark:bg-leaf-600 dark:hover:bg-leaf-500",
    soft: "bg-leaf-50 text-leaf-700 hover:bg-leaf-100 dark:bg-ink-800 dark:text-leaf-200 dark:hover:bg-ink-700",
    ghost: "text-ink-800 hover:bg-sand-100 dark:text-sand-100 dark:hover:bg-ink-800",
  }[variant];
  return (
    <button type={type} disabled={disabled} onClick={onClick} className={`inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition disabled:opacity-50 ${v} ${className}`}>
      {children}
    </button>
  );
}

export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-semibold text-ink-700 dark:text-sand-200">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-[11px] text-ink-600/70 dark:text-sand-300/60">{hint}</span>}
    </label>
  );
}

export const inputCls =
  "w-full rounded-xl border border-sand-300 bg-sand-50 px-3 py-2.5 text-sm text-ink-900 outline-none transition focus:border-citrus-400 focus:bg-white focus:ring-4 focus:ring-citrus-100 dark:border-ink-600 dark:bg-ink-950 dark:text-sand-50 dark:focus:ring-citrus-900/40";

export function refLabel(ref: Ref, lang: "ar" | "en") {
  if (!ref) return "";
  if (ref.kind === "trade") {
    const t = tradeById.get(ref.id);
    return t ? `${lang === "ar" ? t.ar : t.en} — ${t.ai.map((a) => a.substance.split(" (")[0]).join(" + ")}` : "";
  }
  return subById.get(ref.id)?.name ?? "";
}

/** Combobox: search Egyptian trade names (EN/AR) and EU active substances */
export function ProductPicker({ value, onChange, placeholder, subsOnly = false }: { value: Ref; onChange: (r: Ref) => void; placeholder?: string; subsOnly?: boolean }) {
  const { lang, tr } = useLang();
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const box = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (box.current && !box.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);
  const res = useMemo(() => {
    const s = q.trim().toLowerCase();
    const trades = subsOnly
      ? []
      : TRADE.filter((t) => !s || t.en.toLowerCase().includes(s) || t.ar.includes(q.trim()) || t.ai.some((a) => a.substance.toLowerCase().includes(s))).slice(0, s ? 8 : 12);
    const subs = s.length >= 2 || subsOnly ? SUBSTANCES.filter((x) => !s || x.name.toLowerCase().includes(s) || (x.cas ?? "").includes(s)).slice(0, subsOnly && !s ? 0 : 8) : [];
    return { trades, subs };
  }, [q, subsOnly]);

  const label = refLabel(value, lang);
  return (
    <div ref={box} className="relative">
      {value && !open ? (
        <button type="button" onClick={() => { setOpen(true); setQ(""); }} className={`${inputCls} flex items-center justify-between text-start`}>
          <span className="truncate">{label}</span>
          <X
            className="h-4 w-4 shrink-0 text-ink-600/60 hover:text-bad"
            onClick={(e) => {
              e.stopPropagation();
              onChange(null);
            }}
          />
        </button>
      ) : (
        <div className="relative">
          <Search className="pointer-events-none absolute top-1/2 h-4 w-4 -translate-y-1/2 text-ink-600/50 ltr:left-3 rtl:right-3" />
          <input
            autoFocus={open}
            value={q}
            onFocus={() => setOpen(true)}
            onChange={(e) => { setQ(e.target.value); setOpen(true); }}
            placeholder={placeholder ?? tr("Trade name or active substance…", "الاسم التجاري أو المادة الفعالة…")}
            className={`${inputCls} ltr:pl-9 rtl:pr-9`}
          />
        </div>
      )}
      {open && (res.trades.length > 0 || res.subs.length > 0) && (
        <div className="absolute z-30 mt-1 max-h-80 w-full min-w-[280px] overflow-auto rounded-xl border border-sand-200 bg-white p-1 shadow-xl dark:border-ink-700 dark:bg-ink-900">
          {res.trades.length > 0 && <div className="px-3 pb-1 pt-2 text-[10px] font-bold uppercase tracking-wider text-ink-600/60 dark:text-sand-300/50">{tr("Egyptian market trade names", "أسماء تجارية بالسوق المصري")}</div>}
          {res.trades.map((t) => {
            const worst = t.ai.map((a) => classify(a.sid != null ? subById.get(a.sid) ?? null : null).regClass);
            const bad = worst.some((c) => c === "banned" || c === "default" || c === "noUseOnCrop");
            const mid = worst.some((c) => c === "importTolerance" || c === "lowMrl");
            return (
              <button type="button" key={t.id} onClick={() => { onChange({ kind: "trade", id: t.id }); setOpen(false); setQ(""); }} className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-start hover:bg-sand-100 dark:hover:bg-ink-800">
                <span className={`h-2 w-2 shrink-0 rounded-full ${bad ? "bg-bad" : mid ? "bg-warn" : "bg-ok"}`} />
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-semibold">{lang === "ar" ? t.ar : t.en} <span dir="ltr" className="font-normal text-ink-600/60 dark:text-sand-300/60">{t.form !== "—" ? t.form : ""}</span></span>
                  <span className="block truncate text-xs text-ink-600/70 dark:text-sand-300/60" dir="ltr">{t.ai.map((a) => a.substance.split(" (")[0]).join(" + ")}</span>
                </span>
              </button>
            );
          })}
          {res.subs.length > 0 && <div className="px-3 pb-1 pt-2 text-[10px] font-bold uppercase tracking-wider text-ink-600/60 dark:text-sand-300/50">{tr("EU active substances", "المواد الفعالة (قاعدة بيانات الاتحاد الأوروبي)")}</div>}
          {res.subs.map((s) => {
            const c = classify(s).regClass;
            return (
              <button type="button" key={s.id} onClick={() => { onChange({ kind: "sub", id: s.id }); setOpen(false); setQ(""); }} className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-start hover:bg-sand-100 dark:hover:bg-ink-800">
                <span className={`h-2 w-2 shrink-0 rounded-full ${c === "banned" || c === "default" || c === "noUseOnCrop" ? "bg-bad" : c === "importTolerance" || c === "lowMrl" ? "bg-warn" : "bg-ok"}`} />
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm" dir="ltr">{s.name}</span>
                  <span className="block truncate text-xs text-ink-600/70 dark:text-sand-300/60">{lang === "ar" ? REG_LABEL[c].ar : REG_LABEL[c].en}</span>
                </span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

/** Semi-circular clearance gauge */
export function Gauge({ value, level }: { value: number; level: Level }) {
  const { num } = useLang();
  const r = 80;
  const c = Math.PI * r;
  const col = level === "green" ? "#1f9d55" : level === "yellow" ? "#e3a008" : "#d64545";
  return (
    <svg viewBox="0 0 200 120" className="w-full max-w-[260px]" direction="ltr">
      <path d="M20 100 A80 80 0 0 1 180 100" fill="none" stroke="currentColor" className="text-sand-200 dark:text-ink-700" strokeWidth="16" strokeLinecap="round" />
      <path d="M20 100 A80 80 0 0 1 180 100" fill="none" stroke={col} strokeWidth="16" strokeLinecap="round" strokeDasharray={`${c * value} ${c}`} style={{ transition: "stroke-dasharray .8s ease" }} />
      <text x="100" y="92" textAnchor="middle" className="fill-ink-900 dark:fill-white" style={{ font: "800 34px Cairo, sans-serif" }}>
        {value > 0 && value < 0.01 ? "<1" : num(Math.round(value * 100))}%
      </text>
    </svg>
  );
}

export function SectionTitle({ kicker, title, sub }: { kicker?: string; title: string; sub?: string }) {
  return (
    <div className="mb-6">
      {kicker && <div className="mb-2 text-xs font-bold uppercase tracking-[.18em] text-citrus-600 dark:text-citrus-400">{kicker}</div>}
      <h2 className="font-display text-2xl font-extrabold text-ink-900 sm:text-3xl dark:text-white">{title}</h2>
      {sub && <p className="mt-2 max-w-3xl text-sm leading-relaxed text-ink-700/80 dark:text-sand-200/70">{sub}</p>}
    </div>
  );
}
