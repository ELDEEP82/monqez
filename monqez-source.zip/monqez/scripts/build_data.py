"""Build Monqez data JSON from the EU Pesticides Database exports.

Inputs (data-src/):
  MRL_FOR_ORANGES.xlsx                      EU MRLs for product 0110020 Oranges (19/09/2026)
  ActiveSubstanceExport_20-09-2026.xlsx     EU active-substance approval status (20/09/2026)
  trade_names.json                          Sample Egyptian-market trade-name map (demo)
Output: src/data/monqez.json
"""
import json, re, sys
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "data-src"
OUT = ROOT / "src" / "data"
OUT.mkdir(parents=True, exist_ok=True)

# ---------- Active substances ----------
a = pd.read_excel(SRC / "ActiveSubstanceExport_20-09-2026.xlsx", header=2)
a = a[a["Substance"].notna()]

def clean(v):
    if pd.isna(v):
        return None
    s = str(v).strip()
    s = re.sub(r"<[^>]+>", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s or None

def key(name: str) -> str:
    n = name.lower().strip()
    n = re.split(r"\s\(|/\(|\s/", n)[0]
    n = n.replace("’", "'").strip(" ,.")
    return n

subs = []
by_key = {}
for _, r in a.iterrows():
    s = {
        "id": int(r["Active Substance ID"]),
        "name": clean(r["Substance"]),
        "cas": clean(r["CAS Number"]),
        "status": clean(r["Status under Reg. (EC) No 1107/2009"]),
        "approved": clean(r["Date of approval"]),
        "expiry": clean(r["Expiration of approval"]),
        "legislation": clean(r["Legislation"]),
        "cfs": clean(r["Candidate for substitution"]),
        "lowRisk": clean(r["Low-risk a.s."]),
        "basic": clean(r["Basic substance"]),
        "adi": clean(r["ADI (mg/kg bw/d)"]),
        "arfd": clean(r["ARfD (mg/kg bw)"]),
        "functions": clean(r["Functions"]),
        "classification": clean(r["Classification (Reg. 1272/2008)"]),
    }
    if s["legislation"] and len(s["legislation"]) > 260:
        s["legislation"] = s["legislation"][:257] + "…"
    if s["classification"] and len(s["classification"]) > 200:
        s["classification"] = s["classification"][:197] + "…"
    subs.append(s)
    by_key.setdefault(key(s["name"]), []).append(s["id"])

subs_by_id = {s["id"]: s for s in subs}
name_to_id = {s["name"].lower(): s["id"] for s in subs}

# ---------- MRLs for oranges ----------
m = pd.read_excel(SRC / "MRL_FOR_ORANGES.xlsx", header=7)
m.columns = ["pid", "residue", "mrl"]
m = m[m["residue"].notna()].drop_duplicates(subset=["pid", "residue"])

# residue definitions whose name differs from the active-substance name
MANUAL = {
    "carbendazim and benomyl": ["Carbendazim", "Benomyl"],
    "dithiocarbamates": ["Mancozeb", "Maneb", "Metiram", "Propineb", "Thiram", "Ziram"],
    "total copper": ["Copper compounds", "Copper hydroxide", "Copper oxide", "Copper oxychloride"],
    "imazalil": ["Imazalil (aka enilconazole)"],
    "abamectin": ["Abamectin (aka avermectin)"],
    "metalaxyl and metalaxyl-m": ["Metalaxyl", "Metalaxyl-M"],
    "emamectin b1a and its salts, expressed as emamectin b1a": ["Emamectin"],
    "fluvalinate": ["tau-Fluvalinate"],
    "2-phenylphenol": ["2-Phenylphenol (incl. sodium salt orthophenyl phenol)"],
    "phosphonic acid and its salts expressed as phosphonic acid": ["Potassium phosphonates (formerly potassium phosphite)", "Disodium phosphonate", "Fosetyl"],
    "azocyclotin and cyhexatin": ["Azocyclotin", "Cyhexatin"],
    "lambda-cyhalothrin": ["Lambda-Cyhalothrin", "Gamma-cyhalothrin"],
    "spinosad": ["Spinosad"],
    "spinetoram": ["Spinetoram"],
    "spirotetramat and spirotetramat-enol": ["Spirotetramat"],
    "malathion": ["Malathion"],
    "cypermethrin": ["Cypermethrin", "Alpha-Cypermethrin", "Zeta-Cypermethrin", "Beta-Cypermethrin"],
    "cyfluthrin": ["Cyfluthrin", "Beta-Cyfluthrin"],
    "deltamethrin": ["Deltamethrin"],
    "dichlorprop": ["Dichlorprop-P"],
    "clethodim": ["Clethodim"],
    "glufosinate": ["Glufosinate"],
    "flonicamid": ["Flonicamid (IKI-220)"],
    "trimethyl-sulfonium cation, resulting from the use of glyphosate": ["Glyphosate"],
    "chlorpyrifos": ["Chlorpyrifos"],
    "chlorpyrifos-methyl": ["Chlorpyrifos-methyl"],
    "dimethoate": ["Dimethoate"],
    "omethoate": ["Omethoate"],
    "methomyl": ["Methomyl"],
    "thiodicarb": ["Thiodicarb"],
    "profenofos": ["Profenofos"],
    "fenthion": ["Fenthion"],
    "prochloraz": ["Prochloraz"],
    "thiophanate-methyl": ["Thiophanate-methyl"],
    "fosetyl": ["Fosetyl"],
    "hexythiazox": ["Hexythiazox"],
    "lufenuron": ["Lufenuron"],
    "fenpyroximate": ["Fenpyroximate"],
    "pyriproxyfen": ["Pyriproxyfen"],
    "mineral oils": ["Paraffin oil/(CAS 64742-46-7)"],
    "paraffin oil": ["Paraffin oil/(CAS 64742-46-7)"],
}

def norm_res_key(res: str) -> str:
    k = res.lower().strip()
    k = re.split(r"\s\(|:|\s+including\s", k)[0].strip(" ,.")
    k = re.sub(r"^sum of\s+", "", k)
    return k

mrls = []
unmatched = []
for _, r in m.iterrows():
    res = str(r["residue"]).strip()
    raw = r["mrl"]
    if pd.isna(raw):
        val, loq, txt = None, False, None
    else:
        txt = str(raw).strip()
        loq = txt.endswith("*")
        try:
            val = float(txt.rstrip("*"))
        except ValueError:
            val = None
    k = norm_res_key(res)
    ids = []
    if k in MANUAL:
        for nm in MANUAL[k]:
            i = name_to_id.get(nm.lower())
            if i is None:
                i = (by_key.get(key(nm)) or [None])[0]
            if i is not None and i not in ids:
                ids.append(i)
    if not ids and k in by_key:
        ids = list(by_key[k])
    if not ids:
        # try "X and Y" pattern
        for part in re.split(r"\s+and\s+|,\s*", k):
            part = part.strip()
            if part in by_key:
                ids += by_key[part]
    if not ids:
        unmatched.append(res)
    flags = re.findall(r"\(([RFA])\)", res)
    mrls.append({
        "pid": int(r["pid"]),
        "residue": res,
        "mrl": val,
        "loq": loq,
        "raw": txt,
        "flags": sorted(set(flags)),
        "subs": ids,
    })

# ---------- Trade names (demo sample) ----------
trade = json.loads((SRC / "trade_names.json").read_text(encoding="utf-8"))
missing = []
res_by_sub = {}
for mr in mrls:
    for sid in mr["subs"]:
        res_by_sub.setdefault(sid, []).append(mr["pid"])
for t in trade:
    for ai in t["ai"]:
        sid = name_to_id.get(ai["substance"].lower())
        if sid is None:
            missing.append(ai["substance"])
        ai["sid"] = sid
        if "residuePid" not in ai:
            pids = res_by_sub.get(sid, []) if sid else []
            ai["residuePid"] = pids[0] if pids else None

# keep only substances referenced by MRLs or trade names + all for search (compact)
data = {
    "meta": {
        "mrlFile": "EU Pesticides Database – MRLs for 0110020 Oranges (file created 19/09/2026)",
        "asFile": "EU Pesticides Database – Active substances export (file created 20/09/2026)",
        "product": "0110020 – Oranges",
        "counts": {"mrl": len(mrls), "substances": len(subs), "tradeNames": len(trade)},
    },
    "substances": subs,
    "mrls": mrls,
    "trade": trade,
}
(OUT / "monqez.json").write_text(json.dumps(data, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
print("mrls", len(mrls), "unmatched", len(unmatched), "subs", len(subs), "trade", len(trade))
print("missing trade substances:", missing)
if "-v" in sys.argv:
    print("\n".join(unmatched))
