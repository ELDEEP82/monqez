/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  darkMode: "class",
  theme: {
    extend: {
      fontFamily: {
        sans: ['"IBM Plex Sans Arabic"', '"Plus Jakarta Sans"', "system-ui", "sans-serif"],
        display: ['"Cairo"', '"Plus Jakarta Sans"', "system-ui", "sans-serif"],
        mono: ['"JetBrains Mono"', "ui-monospace", "monospace"],
      },
      colors: {
        ink: { 950: "#06140f", 900: "#0b1f18", 800: "#123026", 700: "#1b4334", 600: "#285a46" },
        leaf: { 50: "#eef7f1", 100: "#d6ecdd", 200: "#acd8bb", 300: "#7cbf95", 400: "#4fa271", 500: "#2f8556", 600: "#216a44", 700: "#1b5437" },
        citrus: { 50: "#fff6ec", 100: "#ffe8cc", 200: "#ffcd94", 300: "#ffad57", 400: "#fb8f2a", 500: "#ef7410", 600: "#cc5a09", 700: "#a3440c" },
        sand: { 50: "#fbfaf6", 100: "#f5f2ea", 200: "#ebe5d6", 300: "#dcd3bd" },
        ok: "#1f9d55", warn: "#e3a008", bad: "#d64545",
      },
      boxShadow: { card: "0 1px 0 rgba(6,20,15,.04), 0 8px 24px -12px rgba(6,20,15,.18)" },
    },
  },
  plugins: [],
};
